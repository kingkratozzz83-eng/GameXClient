package com.dodos.gamexclient;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Studio Preview & Editor Tata Letak HUD (Bukan layar hitam kosong!).
 * Menampilkan simulasi latar in-game Minecraft (langit, crosshair, hotbar)
 * agar pengguna bisa mengatur, mengunci (Lock), dan menguji semua HUD & ClickGUI
 * sebelum atau sesudah membuka Minecraft.
 */
public class GameHostActivity extends Activity {
    private HudOverlayController hudController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        );

        ClientSettingsStore.syncAllToNative(this);

        FrameLayout root = new FrameLayout(this);

        // 1. Visualisasi Simulasi Layar In-Game Minecraft (Bukan Layar Hitam!)
        View simulatedWorldView = new View(this) {
            private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

            @Override
            protected void onDraw(Canvas canvas) {
                super.onDraw(canvas);
                int w = getWidth();
                int h = getHeight();

                // Langit senja / malam Minecraft
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(Color.parseColor("#111927"));
                canvas.drawRect(0, 0, w, h * 0.58f, paint);

                // Tanah / Grid blok rumput Minecraft
                paint.setColor(Color.parseColor("#16241B"));
                canvas.drawRect(0, h * 0.58f, w, h, paint);

                // Garis perspektif grid blok
                paint.setColor(Color.parseColor("#243B2C"));
                paint.setStrokeWidth(2f);
                float horizonY = h * 0.58f;
                for (int i = -6; i <= 6; i++) {
                    float startX = (w * 0.5f) + (i * dp(28));
                    float endX = (w * 0.5f) + (i * dp(130));
                    canvas.drawLine(startX, horizonY, endX, h, paint);
                }
                for (int r = 1; r <= 5; r++) {
                    float y = horizonY + ((h - horizonY) * (r / 5.0f));
                    canvas.drawLine(0, y, w, y, paint);
                }

                // Crosshair tengah (+)
                paint.setColor(Color.parseColor("#CCFFFFFF"));
                paint.setStrokeWidth(3f);
                float cx = w * 0.5f;
                float cy = h * 0.5f;
                canvas.drawLine(cx - dp(10), cy, cx + dp(10), cy, paint);
                canvas.drawLine(cx, cy - dp(10), cx, cy + dp(10), paint);

                // Simulasi Hotbar 9 Slot di bagian bawah
                float slotSize = dp(38);
                float totalHotbarW = slotSize * 9;
                float startX = (w - totalHotbarW) * 0.5f;
                float hotbarY = h - slotSize - dp(14);
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(Color.parseColor("#990B0D11"));
                canvas.drawRect(startX, hotbarY, startX + totalHotbarW, hotbarY + slotSize, paint);

                paint.setStyle(Paint.Style.STROKE);
                paint.setColor(Color.parseColor("#8094A3B8"));
                paint.setStrokeWidth(2f);
                for (int s = 0; s < 9; s++) {
                    float sx = startX + (s * slotSize);
                    canvas.drawRect(sx, hotbarY, sx + slotSize, hotbarY + slotSize, paint);
                }
            }
        };
        root.addView(simulatedWorldView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        // 2. Pasang HUD Overlay & ClickGUI GameXClient
        hudController = new HudOverlayController(this, this, null);
        hudController.applyHighRefreshRate(getWindow());
        root.addView(hudController.getInAppContainer());

        // 3. Control Bar Bawah untuk Kembali ke Launcher / Buka Minecraft / Lock HUD
        LinearLayout bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.HORIZONTAL);
        bottomBar.setGravity(Gravity.CENTER_VERTICAL);
        bottomBar.setBackgroundColor(Color.parseColor("#D90B0D11"));
        bottomBar.setPadding(dp(12), dp(6), dp(12), dp(6));

        TextView studioLabel = new TextView(this);
        studioLabel.setText("STUDIO PREVIEW HUD // Ketuk [GX] di atas untuk ON/OFF Modul & Kunci HUD");
        studioLabel.setTextColor(Color.parseColor("#38BDF8"));
        studioLabel.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        studioLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        LinearLayout.LayoutParams labelLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        bottomBar.addView(studioLabel, labelLp);

        Button btnOpenGui = new Button(this);
        btnOpenGui.setText("BUKA MOD MENU [GX]");
        btnOpenGui.setAllCaps(false);
        btnOpenGui.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        btnOpenGui.setTextColor(Color.parseColor("#0B0D11"));
        btnOpenGui.setBackgroundColor(Color.parseColor("#00E5FF"));
        btnOpenGui.setOnClickListener(v -> hudController.toggleClickGui());
        bottomBar.addView(btnOpenGui);

        Button btnBack = new Button(this);
        btnBack.setText("KEMBALI KE MENU");
        btnBack.setAllCaps(false);
        btnBack.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        btnBack.setTextColor(Color.parseColor("#F8FAFC"));
        btnBack.setBackgroundColor(Color.parseColor("#1E293B"));
        LinearLayout.LayoutParams backLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        backLp.leftMargin = dp(8);
        btnBack.setLayoutParams(backLp);
        btnBack.setOnClickListener(v -> finish());
        bottomBar.addView(btnBack);

        FrameLayout.LayoutParams barLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        barLp.gravity = Gravity.TOP;
        root.addView(bottomBar, barLp);

        setContentView(root);

        if (getIntent().getBooleanExtra("open_clickgui_immediately", false)) {
            hudController.toggleClickGui();
        } else {
            Toast.makeText(this, "Ketuk tombol [GX] atau [BUKA MOD MENU] untuk ON/OFF fitur & Lock HUD", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (hudController != null) {
            hudController.destroy();
        }
    }

    private int dp(int val) {
        return Math.round(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, val, getResources().getDisplayMetrics()));
    }
}
