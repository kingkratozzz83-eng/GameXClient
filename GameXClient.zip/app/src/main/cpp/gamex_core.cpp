#include "gamex_core.h"
#include <jni.h>
#include <string>
#include <stdio.h>

#ifdef __ANDROID__
#include <android/log.h>
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "GameXNative", __VA_ARGS__)
#else
#define LOGI(...) printf(__VA_ARGS__)
#endif

extern "C" __attribute__((visibility("default"))) void mod_init() {
    LOGI("GameXClient Native Mod (.so) diinisialisasi via mod_init()");
    gamex::attachToMinecraftEngine(nullptr);
}

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved) {
    (void)vm;
    (void)reserved;
    LOGI("libgamexclient.so berhasil dimuat ke proses memori (JNI_OnLoad)");
    gamex::attachToMinecraftEngine(nullptr);
    return JNI_VERSION_1_6;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_dodos_gamexclient_NativeBridge_nativeAttachEngine(JNIEnv* env, jclass clazz, jstring soPath) {
    (void)clazz;
    const char* pathStr = soPath ? env->GetStringUTFChars(soPath, nullptr) : nullptr;
    int count = gamex::attachToMinecraftEngine(pathStr);
    if (pathStr) {
        env->ReleaseStringUTFChars(soPath, pathStr);
    }
    return count;
}

extern "C" JNIEXPORT void JNICALL
Java_com_dodos_gamexclient_NativeBridge_nativeSetFeatureToggle(JNIEnv* env, jclass clazz, jint featureId, jboolean enabled) {
    (void)env;
    (void)clazz;
    bool val = (enabled == JNI_TRUE);
    switch (featureId) {
        case 0: gamex::gConfig.fpsUnlocker.store(val); break;
        case 1: gamex::gConfig.disableVsync.store(val); break;
        case 2: gamex::gConfig.smoothZoom.store(val); break;
        case 3: gamex::gConfig.freelookEnabled.store(val); break;
        case 4: gamex::gConfig.fullbright.store(val); break;
        case 5: gamex::gConfig.noHurtCam.store(val); break;
        case 6: gamex::gConfig.fpsCpsHud.store(val); break;
        case 7: gamex::gConfig.armorPotionHud.store(val); break;
        case 8: gamex::gConfig.touchstrokesHud.store(val); break;
        case 9: gamex::gConfig.comboReachHud.store(val); break;
        case 10: gamex::gConfig.quickF5Button.store(val); break;
        case 11: gamex::gConfig.autoSprint.store(val); break;
        default: break;
    }
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_dodos_gamexclient_NativeBridge_nativeGetFeatureToggle(JNIEnv* env, jclass clazz, jint featureId) {
    (void)env;
    (void)clazz;
    switch (featureId) {
        case 0: return gamex::gConfig.fpsUnlocker.load();
        case 1: return gamex::gConfig.disableVsync.load();
        case 2: return gamex::gConfig.smoothZoom.load();
        case 3: return gamex::gConfig.freelookEnabled.load();
        case 4: return gamex::gConfig.fullbright.load();
        case 5: return gamex::gConfig.noHurtCam.load();
        case 6: return gamex::gConfig.fpsCpsHud.load();
        case 7: return gamex::gConfig.armorPotionHud.load();
        case 8: return gamex::gConfig.touchstrokesHud.load();
        case 9: return gamex::gConfig.comboReachHud.load();
        case 10: return gamex::gConfig.quickF5Button.load();
        case 11: return gamex::gConfig.autoSprint.load();
        default: return JNI_FALSE;
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_dodos_gamexclient_NativeBridge_nativeSetTargetFps(JNIEnv* env, jclass clazz, jint fps) {
    (void)env;
    (void)clazz;
    gamex::gConfig.targetFps.store(fps);
}

extern "C" JNIEXPORT jint JNICALL
Java_com_dodos_gamexclient_NativeBridge_nativeGetTargetFps(JNIEnv* env, jclass clazz) {
    (void)env;
    (void)clazz;
    return gamex::gConfig.targetFps.load();
}

extern "C" JNIEXPORT void JNICALL
Java_com_dodos_gamexclient_NativeBridge_nativeSetZoomState(JNIEnv* env, jclass clazz, jboolean active, jfloat multiplier) {
    (void)env;
    (void)clazz;
    gamex::gConfig.zoomActive.store(active == JNI_TRUE);
    if (multiplier >= 1.5f && multiplier <= 10.0f) {
        gamex::gConfig.zoomMultiplier.store(multiplier);
    }
}

extern "C" JNIEXPORT jfloat JNICALL
Java_com_dodos_gamexclient_NativeBridge_nativeTickEffectiveFov(JNIEnv* env, jclass clazz, jfloat baseFov, jfloat dt) {
    (void)env;
    (void)clazz;
    return gamex::computeEffectiveFov(baseFov, dt);
}

extern "C" JNIEXPORT void JNICALL
Java_com_dodos_gamexclient_NativeBridge_nativeSetFreelookDelta(JNIEnv* env, jclass clazz, jboolean active, jfloat dYaw, jfloat dPitch) {
    (void)env;
    (void)clazz;
    gamex::gConfig.freelookActive.store(active == JNI_TRUE);
    if (active) {
        gamex::gConfig.freelookYaw.store(gamex::gConfig.freelookYaw.load() + dYaw);
        float p = gamex::gConfig.freelookPitch.load() + dPitch;
        if (p > 89.0f) p = 89.0f;
        if (p < -89.0f) p = -89.0f;
        gamex::gConfig.freelookPitch.store(p);
    } else {
        gamex::gConfig.freelookYaw.store(0.0f);
        gamex::gConfig.freelookPitch.store(0.0f);
    }
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_dodos_gamexclient_NativeBridge_nativeGetEngineDiagnostic(JNIEnv* env, jclass clazz) {
    (void)clazz;
    char buf[256];
    uintptr_t base = gamex::gConfig.mcpeBaseAddr.load();
    int hooks = gamex::gConfig.hookedSymbolsCount.load();
    float fov = gamex::computeEffectiveFov(70.0f, 0.016f);
    float gamma = gamex::computeEffectiveGamma(1.0f);
    snprintf(buf, sizeof(buf),
             "Engine: libgamexclient.so (ARM64) | Hooks: %d | FOV: %.1f | Gamma: %.1f",
             hooks, fov, gamma);
    return env->NewStringUTF(buf);
}
