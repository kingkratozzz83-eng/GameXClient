package com.dodos.gamexclient;

import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.WindowManager;

public class OverlayHudService extends Service {
    private HudOverlayController overlayController;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "STOP_OVERLAY".equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) {
            if (overlayController == null) {
                WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
                overlayController = new HudOverlayController(this, null, wm);
            } else {
                overlayController.refreshAllStates();
            }
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (overlayController != null) {
            overlayController.destroy();
            overlayController = null;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
