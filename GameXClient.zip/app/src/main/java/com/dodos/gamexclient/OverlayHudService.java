package com.dodos.gamexclient;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.WindowManager;

public class OverlayHudService extends Service {
    private static final String CHANNEL_ID = "gamexclient_hud_channel";
    private static final int NOTIF_ID = 1001;

    private HudOverlayController overlayController;
    private PowerManager.WakeLock wakeLock;

    @Override
    public void onCreate() {
        super.onCreate();
        startPersistentForeground();
        acquireSafeWakeLock();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "STOP_OVERLAY".equals(intent.getAction())) {
            releaseSafeWakeLock();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        startPersistentForeground();

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) {
            if (overlayController == null) {
                WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
                overlayController = new HudOverlayController(this, null, wm);
            } else {
                overlayController.refreshAllStates();
            }
        }
        return START_STICKY;
    }

    private void startPersistentForeground() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && nm != null) {
                NotificationChannel channel = new NotificationChannel(
                        CHANNEL_ID,
                        "GameXClient In-Game HUD",
                        NotificationManager.IMPORTANCE_LOW
                );
                channel.setDescription("Menjaga HUD GameXClient tetap aktif di dalam Minecraft");
                nm.createNotificationChannel(channel);
            }

            Intent openIntent = new Intent(this, MainActivity.class);
            int piFlags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                piFlags |= PendingIntent.FLAG_IMMUTABLE;
            }
            PendingIntent pi = PendingIntent.getActivity(this, 0, openIntent, piFlags);

            Notification.Builder builder = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    ? new Notification.Builder(this, CHANNEL_ID)
                    : new Notification.Builder(this);

            Notification notif = builder
                    .setContentTitle("GameXClient HUD Aktif")
                    .setContentText("HUD terkunci & berjalan di atas Minecraft. Ketuk [GX] di layar untuk Mod Menu.")
                    .setSmallIcon(android.R.drawable.ic_media_play)
                    .setContentIntent(pi)
                    .setOngoing(true)
                    .build();

            startForeground(NOTIF_ID, notif);
        } catch (Throwable ignored) {
        }
    }

    private void acquireSafeWakeLock() {
        try {
            if (wakeLock == null) {
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                if (pm != null) {
                    wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GameXClient::HudKeepAlive");
                    wakeLock.setReferenceCounted(false);
                    wakeLock.acquire(4 * 60 * 60 * 1000L);
                }
            }
        } catch (Throwable ignored) {
        }
    }

    private void releaseSafeWakeLock() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) {
                wakeLock.release();
            }
        } catch (Throwable ignored) {
        }
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        // Pastikan HUD tetap hidup meskipun kartu aplikasi Launcher di-swipe dari Recent Apps
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        releaseSafeWakeLock();
        if (overlayController != null) {
            overlayController.destroy();
            overlayController = null;
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
