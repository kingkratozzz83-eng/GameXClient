#pragma once
#include <stdint.h>
#include <stdbool.h>
#include <atomic>

namespace gamex {

struct ClientConfig {
    std::atomic<bool> fpsUnlocker{true};
    std::atomic<int> targetFps{120};
    std::atomic<bool> disableVsync{true};
    std::atomic<bool> smoothZoom{true};
    std::atomic<bool> zoomActive{false};
    std::atomic<float> zoomMultiplier{4.0f};
    std::atomic<float> currentZoomLerp{1.0f};
    std::atomic<bool> freelookEnabled{true};
    std::atomic<bool> freelookActive{false};
    std::atomic<float> freelookYaw{0.0f};
    std::atomic<float> freelookPitch{0.0f};
    std::atomic<bool> fullbright{false};
    std::atomic<bool> noHurtCam{true};

    std::atomic<bool> fpsCpsHud{true};
    std::atomic<bool> armorPotionHud{true};
    std::atomic<bool> touchstrokesHud{true};
    std::atomic<bool> comboReachHud{true};
    std::atomic<bool> quickF5Button{true};
    std::atomic<bool> autoSprint{true};

    std::atomic<bool> mcpeLoaded{false};
    std::atomic<uintptr_t> mcpeBaseAddr{0};
    std::atomic<int> hookedSymbolsCount{0};
};

extern ClientConfig gConfig;

uintptr_t findLibraryBase(const char* soname);
bool patchMemoryFloat(uintptr_t addr, float value);
bool installArm64Trampoline(uintptr_t targetAddr, void* detourFunc, void** origFuncOut);
int attachToMinecraftEngine(const char* mcpeSoPath);

float computeEffectiveFov(float vanillaFov, float deltaTime);
float computeEffectiveGamma(float vanillaGamma);

} // namespace gamex
