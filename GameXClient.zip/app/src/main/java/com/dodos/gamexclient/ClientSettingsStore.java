package com.dodos.gamexclient;

import android.content.Context;
import android.content.SharedPreferences;

public class ClientSettingsStore {
    private static final String PREF_NAME = "gamex_client_prefs";

    public static void syncAllToNative(Context ctx) {
        SharedPreferences prefs = ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        for (int i = 0; i <= 11; i++) {
            boolean defVal = (i != NativeBridge.FEAT_FULLBRIGHT);
            boolean enabled = prefs.getBoolean("feat_" + i, defVal);
            if (NativeBridge.isNativeLoaded()) {
                NativeBridge.nativeSetFeatureToggle(i, enabled);
            }
        }
        int targetFps = prefs.getInt("target_fps", 120);
        float zoomMult = prefs.getFloat("zoom_mult", 4.0f);
        if (NativeBridge.isNativeLoaded()) {
            NativeBridge.nativeSetTargetFps(targetFps);
            NativeBridge.nativeSetZoomState(false, zoomMult);
        }
    }

    public static boolean isFeatureEnabled(Context ctx, int featId) {
        SharedPreferences prefs = ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        boolean defVal = (featId != NativeBridge.FEAT_FULLBRIGHT);
        return prefs.getBoolean("feat_" + featId, defVal);
    }

    public static void setFeatureEnabled(Context ctx, int featId, boolean enabled) {
        SharedPreferences prefs = ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        prefs.edit().putBoolean("feat_" + featId, enabled).apply();
        if (NativeBridge.isNativeLoaded()) {
            NativeBridge.nativeSetFeatureToggle(featId, enabled);
        }
    }

    public static int getTargetFps(Context ctx) {
        return ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).getInt("target_fps", 120);
    }

    public static void setTargetFps(Context ctx, int fps) {
        ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).edit().putInt("target_fps", fps).apply();
        if (NativeBridge.isNativeLoaded()) {
            NativeBridge.nativeSetTargetFps(fps);
        }
    }

    public static float getZoomMultiplier(Context ctx) {
        return ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).getFloat("zoom_mult", 4.0f);
    }

    public static void setZoomMultiplier(Context ctx, float mult) {
        ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).edit().putFloat("zoom_mult", mult).apply();
        if (NativeBridge.isNativeLoaded()) {
            NativeBridge.nativeSetZoomState(false, mult);
        }
    }

    public static void saveWidgetPosition(Context ctx, String widgetKey, float x, float y) {
        ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
           .edit()
           .putFloat(widgetKey + "_x", x)
           .putFloat(widgetKey + "_y", y)
           .apply();
    }

    public static float getWidgetX(Context ctx, String widgetKey, float defaultX) {
        return ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).getFloat(widgetKey + "_x", defaultX);
    }

    public static float getWidgetY(Context ctx, String widgetKey, float defaultY) {
        return ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).getFloat(widgetKey + "_y", defaultY);
    }
}
