package com.dodos.gamexclient;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private TextView tvStatus;
    private Button btnLockStateMain;
    private final List<Runnable> moduleRowUpdaters = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        ClientSettingsStore.syncAllToNative(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.HORIZONTAL);
        root.setBackgroundColor(Color.parseColor("#0B0D11"));
        root.setPadding(dp(16), dp(14), dp(16), dp(14));

        // ================= PANEL KIRI: LAUNCHER & ANTI-KILL OVERLAY =================
        LinearLayout leftPanel = new LinearLayout(this);
        leftPanel.setOrientation(LinearLayout.VERTICAL);
        leftPanel.setPadding(dp(16), dp(14), dp(16), dp(14));
        GradientDrawable leftBg = new GradientDrawable();
        leftBg.setColor(Color.parseColor("#12161F"));
        leftBg.setCornerRadius(dp(14));
        leftBg.setStroke(dp(1), Color.parseColor("#1E293B"));
        leftPanel.setBackground(leftBg);

        LinearLayout.LayoutParams leftLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.05f);
        leftLp.rightMargin = dp(14);

        TextView badge = new TextView(this);
        badge.setText("MINECRAFT BEDROCK // NATIVE CLIENT v1.2");
        badge.setTextColor(Color.parseColor("#00E5FF"));
        badge.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        badge.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        leftPanel.addView(badge);

        TextView title = new TextView(this);
        title.setText("GameXClient");
        title.setTextColor(Color.parseColor("#F8FAFC"));
        title.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        title.setPadding(0, dp(2), 0, dp(2));
        leftPanel.addView(title);

        tvStatus = new TextView(this);
        tvStatus.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
        tvStatus.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        tvStatus.setTextColor(Color.parseColor("#10B981"));
        tvStatus.setPadding(dp(10), dp(8), dp(10), dp(8));
        GradientDrawable diagBg = new GradientDrawable();
        diagBg.setColor(Color.parseColor("#090C10"));
        diagBg.setCornerRadius(dp(8));
        diagBg.setStroke(dp(1), Color.parseColor("#1E293B"));
        tvStatus.setBackground(diagBg);
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        statusLp.topMargin = dp(6);
        statusLp.bottomMargin = dp(8);
        leftPanel.addView(tvStatus, statusLp);

        // Tombol 1: MAIN LAUNCHER -> Aktifkan Foreground Service Anti-Kill + Buka Minecraft!
        leftPanel.addView(createPrimaryButton(
                "MAIN MINECRAFT + GAMEX HUD (ANTI-HILANG)",
                "Menjalankan Foreground Service + WakeLock agar HUD & [GX] tetap aktif di dalam Minecraft",
                "#10B981", "#064E3B",
                v -> launchMinecraftWithPersistentOverlay()
        ));

        // Tombol 2: STUDIO ATUR POSISI & LOCK HUD
        leftPanel.addView(createPrimaryButton(
                "STUDIO ATUR POSISI & LOCK HUD",
                "Uji Crosshair, Zoom Scope, Fullbright, dan geser posisi HUD sebelum masuk game",
                "#00E5FF", "#082F49",
                v -> startActivity(new Intent(this, GameHostActivity.class))
        ));

        // Baris Tombol Cepat: MATIKAN OVERLAY & EXPORT .LEVIPACK
        LinearLayout actionRow = new LinearLayout(this);
        actionRow.setOrientation(LinearLayout.HORIZONTAL);

        Button btnStopOverlay = new Button(this);
        btnStopOverlay.setText("MATIKAN OVERLAY");
        btnStopOverlay.setAllCaps(false);
        btnStopOverlay.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        btnStopOverlay.setTextColor(Color.parseColor("#F87171"));
        btnStopOverlay.setBackgroundColor(Color.parseColor("#1E293B"));
        LinearLayout.LayoutParams stopLp = new LinearLayout.LayoutParams(0, dp(36), 1f);
        stopLp.rightMargin = dp(6);
        btnStopOverlay.setOnClickListener(v -> {
            Intent stopIntent = new Intent(this, OverlayHudService.class);
            stopIntent.setAction("STOP_OVERLAY");
            startService(stopIntent);
            Toast.makeText(this, "Overlay GameXClient dimatikan", Toast.LENGTH_SHORT).show();
        });
        actionRow.addView(btnStopOverlay, stopLp);

        Button btnExportSo = new Button(this);
        btnExportSo.setText("EXPORT .LEVIPACK");
        btnExportSo.setAllCaps(false);
        btnExportSo.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        btnExportSo.setTextColor(Color.parseColor("#C084FC"));
        btnExportSo.setBackgroundColor(Color.parseColor("#1E293B"));
        LinearLayout.LayoutParams expLp = new LinearLayout.LayoutParams(0, dp(36), 1f);
        btnExportSo.setOnClickListener(v -> {
            File pack = McpePackageExtractor.exportStandaloneLevipack(this);
            if (pack != null) {
                Toast.makeText(this, "Disimpan: " + pack.getAbsolutePath(), Toast.LENGTH_LONG).show();
            }
        });
        actionRow.addView(btnExportSo, expLp);

        leftPanel.addView(actionRow);

        // ================= PANEL KANAN: PENGATURAN ON/OFF MODUL & KUNCI HUD =================
        LinearLayout rightContainer = new LinearLayout(this);
        rightContainer.setOrientation(LinearLayout.VERTICAL);
        rightContainer.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable rightBg = new GradientDrawable();
        rightBg.setColor(Color.parseColor("#12161F"));
        rightBg.setCornerRadius(dp(14));
        rightBg.setStroke(dp(1), Color.parseColor("#1E293B"));
        rightContainer.setBackground(rightBg);

        LinearLayout rightHeader = new LinearLayout(this);
        rightHeader.setOrientation(LinearLayout.HORIZONTAL);
        rightHeader.setGravity(Gravity.CENTER_VERTICAL);

        TextView rightTitle = new TextView(this);
        rightTitle.setText("PILIH FITUR AKTIF (ON / OFF)");
        rightTitle.setTextColor(Color.parseColor("#00E5FF"));
        rightTitle.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        rightTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        rightHeader.addView(rightTitle, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        btnLockStateMain = new Button(this);
        btnLockStateMain.setAllCaps(false);
        btnLockStateMain.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        btnLockStateMain.setOnClickListener(v -> {
            boolean nextLock = !ClientSettingsStore.isHudLocked(this);
            ClientSettingsStore.setHudLocked(this, nextLock);
            refreshUI();
            startPersistentServiceUpdate();
            Toast.makeText(this, nextLock
                    ? "Posisi HUD DIKUNCI (Sentuhan tembus ke game)"
                    : "Mode Geser HUD Aktif", Toast.LENGTH_SHORT).show();
        });
        rightHeader.addView(btnLockStateMain);

        rightContainer.addView(rightHeader);

        LinearLayout quickBar = new LinearLayout(this);
        quickBar.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams qbLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        qbLp.topMargin = dp(6);
        qbLp.bottomMargin = dp(6);
        quickBar.setLayoutParams(qbLp);

        Button btnDisableAll = new Button(this);
        btnDisableAll.setText("Nonaktifkan Semua HUD");
        btnDisableAll.setAllCaps(false);
        btnDisableAll.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        btnDisableAll.setTextColor(Color.parseColor("#FDE047"));
        btnDisableAll.setBackgroundColor(Color.parseColor("#1E293B"));
        btnDisableAll.setOnClickListener(v -> {
            ClientSettingsStore.setAllHudFeatures(this, false);
            refreshUI();
            startPersistentServiceUpdate();
        });
        quickBar.addView(btnDisableAll, new LinearLayout.LayoutParams(0, dp(34), 1f));

        Button btnEnableAll = new Button(this);
        btnEnableAll.setText("Aktifkan Semua");
        btnEnableAll.setAllCaps(false);
        btnEnableAll.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        btnEnableAll.setTextColor(Color.parseColor("#10B981"));
        btnEnableAll.setBackgroundColor(Color.parseColor("#1E293B"));
        LinearLayout.LayoutParams eaLp = new LinearLayout.LayoutParams(0, dp(34), 0.8f);
        eaLp.leftMargin = dp(6);
        btnEnableAll.setOnClickListener(v -> {
            ClientSettingsStore.setAllHudFeatures(this, true);
            refreshUI();
            startPersistentServiceUpdate();
        });
        quickBar.addView(btnEnableAll, eaLp);

        rightContainer.addView(quickBar);

        ScrollView modScroll = new ScrollView(this);
        LinearLayout modList = new LinearLayout(this);
        modList.setOrientation(LinearLayout.VERTICAL);

        for (int i = 0; i <= 11; i++) {
            final int featId = i;
            TextView row = new TextView(this);
            row.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
            row.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            row.setPadding(dp(12), dp(8), dp(12), dp(8));
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rlp.bottomMargin = dp(5);
            row.setLayoutParams(rlp);

            Runnable updater = () -> {
                boolean on = ClientSettingsStore.isFeatureEnabled(this, featId);
                row.setText((on ? "[ON]  " : "[OFF] ") + NativeBridge.FEATURE_NAMES[featId]);
                row.setTextColor(on ? Color.parseColor("#10B981") : Color.parseColor("#94A3B8"));
                GradientDrawable bg = new GradientDrawable();
                bg.setCornerRadius(dp(8));
                bg.setColor(on ? Color.parseColor("#0D2821") : Color.parseColor("#090C10"));
                bg.setStroke(dp(1), on ? Color.parseColor("#10B981") : Color.parseColor("#1E293B"));
                row.setBackground(bg);
            };
            moduleRowUpdaters.add(updater);

            row.setOnClickListener(v -> {
                boolean next = !ClientSettingsStore.isFeatureEnabled(this, featId);
                ClientSettingsStore.setFeatureEnabled(this, featId, next);
                refreshUI();
                startPersistentServiceUpdate();
            });
            modList.addView(row);
        }

        modScroll.addView(modList);
        rightContainer.addView(modScroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        root.addView(leftPanel, leftLp);
        root.addView(rightContainer, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.25f));

        setContentView(root);
        refreshUI();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshUI();
    }

    private void startPersistentServiceUpdate() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) {
            Intent svc = new Intent(this, OverlayHudService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(svc);
            } else {
                startService(svc);
            }
        }
    }

    private void launchMinecraftWithPersistentOverlay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izinkan 'Tampilkan di atas aplikasi lain' untuk GameXClient, lalu tekan tombol ini lagi", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
            return;
        }

        // Minta pengecualian penghemat baterai (opsional tapi menjaga agar sistem iQOO/OriginOS tidak pernah mematikan HUD)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
                    Intent battIntent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                    battIntent.setData(Uri.parse("package:" + getPackageName()));
                    startActivity(battIntent);
                }
            } catch (Throwable ignored) {
            }
        }

        // 1. Jalankan Foreground Service Anti-Kill
        startPersistentServiceUpdate();

        // 2. Buka aplikasi Minecraft
        boolean launched = McpePackageExtractor.launchMinecraftApp(this);
        if (!launched) {
            Toast.makeText(this, "Minecraft belum terdeteksi, membuka Studio Preview HUD...", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, GameHostActivity.class));
        } else {
            Toast.makeText(this, "GameXClient HUD Aktif Permanen! Ketuk tombol [GX] di layar saat bermain.", Toast.LENGTH_LONG).show();
        }
    }

    private View createPrimaryButton(String headline, String sub, String borderHex, String bgHex, View.OnClickListener listener) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(10), dp(12), dp(10));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(bgHex));
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), Color.parseColor(borderHex));
        box.setBackground(bg);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(8);
        box.setLayoutParams(lp);

        TextView h = new TextView(this);
        h.setText(headline);
        h.setTextColor(Color.parseColor(borderHex));
        h.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        h.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        box.addView(h);

        TextView s = new TextView(this);
        s.setText(sub);
        s.setTextColor(Color.parseColor("#E2E8F0"));
        s.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        s.setPadding(0, dp(2), 0, 0);
        box.addView(s);

        box.setOnClickListener(listener);
        return box;
    }

    private void refreshUI() {
        McpePackageExtractor.McpeEnvironment env = McpePackageExtractor.inspect(this);
        String mcStatus = env.installed
                ? "MCPE Siap: v" + env.versionName + " | Target: " + ClientSettingsStore.getTargetFps(this) + "Hz"
                : "MCPE belum terdeteksi | Studio HUD Siap";
        boolean locked = ClientSettingsStore.isHudLocked(this);
        tvStatus.setText(mcStatus + "\nForeground HUD: AKTIF (Anti-Hilang) | Posisi: " + (locked ? "TERKUNCI" : "MODE GESER"));

        if (btnLockStateMain != null) {
            btnLockStateMain.setText(locked ? "HUD: TERKUNCI" : "HUD: BISA DIGESER");
            btnLockStateMain.setTextColor(Color.parseColor("#0B0D11"));
            btnLockStateMain.setBackgroundColor(locked
                    ? Color.parseColor("#10B981")
                    : Color.parseColor("#F59E0B"));
        }

        for (Runnable r : moduleRowUpdaters) {
            r.run();
        }
    }

    private int dp(int val) {
        return Math.round(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, val, getResources().getDisplayMetrics()));
    }
}
