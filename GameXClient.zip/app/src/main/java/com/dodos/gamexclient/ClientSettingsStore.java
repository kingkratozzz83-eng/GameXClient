package com.dodos.gamexclient;

import android.content.Context;
import android.content.SharedPreferences;

public class ClientSettingsStore {
    private static final String PREF_NAME = "gamex_client_prefs_v3";

    public static boolean getDefaultFeatureState(int featId) {
        return featId == NativeBridge.FEAT_FPS_UNLOCKER
                || featId == NativeBridge.FEAT_DISABLE_VSYNC
                || featId == NativeBridge.FEAT_CUSTOM_CROSSHAIR
                || featId == NativeBridge.FEAT_FPS_CPS_HUD;
    }

    public static void syncAllToNative(Context ctx) {
        SharedPreferences prefs = ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        for (int i = 0; i <= 11; i++) {
            boolean enabled = prefs.getBoolean("feat_" + i, getDefaultFeatureState(i));
            if (NativeBridge.isNativeLoaded()) {
                NativeBridge.nativeSetFeatureToggle(i, enabled);
            }
        }
        int targetFps = prefs.getInt("target_fps", 120);
        float zoomMult = prefs.getFloat("zoom_mult", 4.0f);
        if (NativeBridge.isNativeLoaded()) {
            NativeBridge.nativeSetTargetFps(targetFps);
            NativeBridge.nativeSetZoomState(false, zoomMult);
        }
    }

    public static boolean isFeatureEnabled(Context ctx, int featId) {
        SharedPreferences prefs = ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return prefs.getBoolean("feat_" + featId, getDefaultFeatureState(featId));
    }

    public static void setFeatureEnabled(Context ctx, int featId, boolean enabled) {
        SharedPreferences prefs = ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        prefs.edit().putBoolean("feat_" + featId, enabled).apply();
        if (NativeBridge.isNativeLoaded()) {
            NativeBridge.nativeSetFeatureToggle(featId, enabled);
        }
    }

    public static void setAllHudFeatures(Context ctx, boolean enabled) {
        SharedPreferences.Editor ed = ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).edit();
        for (int i = 2; i <= 11; i++) {
            ed.putBoolean("feat_" + i, enabled);
            if (NativeBridge.isNativeLoaded()) {
                NativeBridge.nativeSetFeatureToggle(i, enabled);
            }
        }
        ed.apply();
    }

    public static boolean isHudLocked(Context ctx) {
        return ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).getBoolean("hud_locked", true);
    }

    public static void setHudLocked(Context ctx, boolean locked) {
        ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
           .edit()
           .putBoolean("hud_locked", locked)
           .apply();
    }

    public static int getTargetFps(Context ctx) {
        return ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).getInt("target_fps", 120);
    }

    public static void setTargetFps(Context ctx, int fps) {
        ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).edit().putInt("target_fps", fps).apply();
        if (NativeBridge.isNativeLoaded()) {
            NativeBridge.nativeSetTargetFps(fps);
        }
    }

    public static float getZoomMultiplier(Context ctx) {
        return ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).getFloat("zoom_mult", 4.0f);
    }

    public static void setZoomMultiplier(Context ctx, float mult) {
        ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).edit().putFloat("zoom_mult", mult).apply();
        if (NativeBridge.isNativeLoaded()) {
            NativeBridge.nativeSetZoomState(false, mult);
        }
    }

    public static void saveWidgetPosition(Context ctx, String widgetKey, float x, float y) {
        ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
           .edit()
           .putFloat(widgetKey + "_x", x)
           .putFloat(widgetKey + "_y", y)
           .apply();
    }

    public static float getWidgetX(Context ctx, String widgetKey, float defaultX) {
        return ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).getFloat(widgetKey + "_x", defaultX);
    }

    public static float getWidgetY(Context ctx, String widgetKey, float defaultY) {
        return ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).getFloat(widgetKey + "_y", defaultY);
    }

    public static void resetWidgetPositions(Context ctx) {
        SharedPreferences prefs = ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = prefs.edit();
        String[] keys = new String[]{
            "hud_fps", "hud_combo", "hud_armor", "hud_sprint",
            "hud_touchstrokes", "btn_f5", "btn_zoom", "btn_freelook", "btn_gx_main"
        };
        for (String k : keys) {
            ed.remove(k + "_x");
            ed.remove(k + "_y");
        }
        ed.apply();
    }
}
