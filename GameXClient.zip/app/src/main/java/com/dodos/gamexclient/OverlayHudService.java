package com.dodos.gamexclient;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;

public class OverlayHudService extends Service {
    private WindowManager windowManager;
    private HudOverlayController overlayController;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(this)) {
            if (overlayController == null) {
                windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
                overlayController = new HudOverlayController(this, null);

                int layoutType = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE;

                WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                        WindowManager.LayoutParams.MATCH_PARENT,
                        WindowManager.LayoutParams.MATCH_PARENT,
                        layoutType,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                        PixelFormat.TRANSLUCENT
                );
                params.gravity = Gravity.TOP | Gravity.START;
                try {
                    windowManager.addView(overlayController.getRootView(), params);
                } catch (Throwable ignored) {
                }
            }
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (overlayController != null && windowManager != null) {
            try {
                windowManager.removeView(overlayController.getRootView());
            } catch (Throwable ignored) {
            }
            overlayController.destroy();
            overlayController = null;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
