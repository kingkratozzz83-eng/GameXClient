package com.dodos.gamexclient;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

public class McpePackageExtractor {
    public static final String MCPE_PACKAGE = "com.mojang.minecraftpe";

    public static class McpeEnvironment {
        public boolean installed;
        public String versionName = "Tidak Terdeteksi";
        public long versionCode = 0;
        public String baseApkPath = "";
        public List<String> splitApkPaths = new ArrayList<>();
        public File extractedNativeDir;
        public File libMinecraftPeSo;
        public List<String> extractedLibs = new ArrayList<>();
    }

    public static McpeEnvironment inspectAndPrepare(Context context, boolean extractLibsNow) {
        McpeEnvironment env = new McpeEnvironment();
        env.extractedNativeDir = new File(context.getFilesDir(), "mcpe_native_arm64");
        if (!env.extractedNativeDir.exists()) {
            env.extractedNativeDir.mkdirs();
        }

        try {
            PackageManager pm = context.getPackageManager();
            PackageInfo pkgInfo = pm.getPackageInfo(MCPE_PACKAGE, 0);
            ApplicationInfo appInfo = pm.getApplicationInfo(MCPE_PACKAGE, 0);

            env.installed = true;
            env.versionName = pkgInfo.versionName != null ? pkgInfo.versionName : "1.21+";
            env.versionCode = pkgInfo.getLongVersionCode();
            env.baseApkPath = appInfo.sourceDir;

            if (appInfo.splitSourceDirs != null) {
                for (String split : appInfo.splitSourceDirs) {
                    env.splitApkPaths.add(split);
                }
            }

            if (extractLibsNow) {
                List<String> allApks = new ArrayList<>();
                allApks.add(env.baseApkPath);
                allApks.addAll(env.splitApkPaths);

                for (String apkPath : allApks) {
                    extractArm64SoFromApk(apkPath, env.extractedNativeDir, env.extractedLibs);
                }
            }

            File candidateSo = new File(env.extractedNativeDir, "libminecraftpe.so");
            if (candidateSo.exists() && candidateSo.length() > 0) {
                env.libMinecraftPeSo = candidateSo;
            } else if (appInfo.nativeLibraryDir != null) {
                File sysSo = new File(appInfo.nativeLibraryDir, "libminecraftpe.so");
                if (sysSo.exists()) {
                    env.libMinecraftPeSo = sysSo;
                }
            }
        } catch (PackageManager.NameNotFoundException e) {
            env.installed = false;
        } catch (Throwable t) {
            env.installed = false;
        }
        return env;
    }

    private static void extractArm64SoFromApk(String apkPath, File outDir, List<String> extractedList) {
        if (apkPath == null || apkPath.isEmpty()) return;
        File apkFile = new File(apkPath);
        if (!apkFile.exists()) return;

        try (ZipFile zip = new ZipFile(apkFile)) {
            Enumeration<? extends ZipEntry> entries = zip.entries();
            byte[] buffer = new byte[65536];
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                String name = entry.getName();
                if (!entry.isDirectory() && name.startsWith("lib/arm64-v8a/") && name.endsWith(".so")) {
                    String fileName = name.substring("lib/arm64-v8a/".length());
                    File outFile = new File(outDir, fileName);
                    if (!outFile.exists() || outFile.length() != entry.getSize()) {
                        try (InputStream is = zip.getInputStream(entry);
                             FileOutputStream fos = new FileOutputStream(outFile)) {
                            int read;
                            while ((read = is.read(buffer)) != -1) {
                                fos.write(buffer, 0, read);
                            }
                        }
                    }
                    outFile.setReadable(true, false);
                    outFile.setExecutable(true, false);
                    extractedList.add(fileName);
                }
            }
        } catch (Exception ignored) {
        }
    }

    /**
     * Mengekspor paket .levipack / libgamexclient.so agar juga bisa diimpor ke LeviLauncher jika diinginkan.
     */
    public static File exportStandaloneLevipack(Context context) {
        try {
            File nativeDir = new File(context.getApplicationInfo().nativeLibraryDir);
            File ourSo = new File(nativeDir, "libgamexclient.so");
            File outDir = context.getExternalFilesDir(null);
            if (outDir == null) outDir = context.getFilesDir();
            File packFile = new File(outDir, "GameXClient-Mod-arm64.levipack");

            try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(packFile))) {
                // 1. manifest.json untuk LeviLauncher
                String manifest = "{
"
                        + "  "format_version": 1,
"
                        + "  "id": "gamexclient",
"
                        + "  "name": "GameXClient Native Pack",
"
                        + "  "version": "1.0.0",
"
                        + "  "author": "dodosadventure",
"
                        + "  "entry": "libgamexclient.so",
"
                        + "  "platform": "android-arm64-v8a"
"
                        + "}
";
                zos.putNextEntry(new ZipEntry("manifest.json"));
                zos.write(manifest.getBytes("UTF-8"));
                zos.closeEntry();

                // 2. libgamexclient.so
                if (ourSo.exists()) {
                    zos.putNextEntry(new ZipEntry("libgamexclient.so"));
                    try (FileInputStream fis = new FileInputStream(ourSo)) {
                        byte[] buf = new byte[32768];
                        int len;
                        while ((len = fis.read(buf)) > 0) {
                            zos.write(buf, 0, len);
                        }
                    }
                    zos.closeEntry();
                }
            }
            return packFile;
        } catch (Exception e) {
            return null;
        }
    }
}
