package com.dodos.gamexclient;

public class NativeBridge {
    public static final int FEAT_FPS_UNLOCKER   = 0;
    public static final int FEAT_DISABLE_VSYNC  = 1;
    public static final int FEAT_SMOOTH_ZOOM    = 2;
    public static final int FEAT_FREELOOK       = 3;
    public static final int FEAT_FULLBRIGHT     = 4;
    public static final int FEAT_NO_HURTCAM     = 5;
    public static final int FEAT_FPS_CPS_HUD    = 6;
    public static final int FEAT_ARMOR_HUD      = 7;
    public static final int FEAT_TOUCHSTROKES   = 8;
    public static final int FEAT_COMBO_REACH    = 9;
    public static final int FEAT_QUICK_F5       = 10;
    public static final int FEAT_AUTO_SPRINT    = 11;

    public static final String[] FEATURE_NAMES = new String[]{
        "FPS Unlocker (120Hz)",
        "Disable V-Sync",
        "Tombol Smooth Zoom (4x)",
        "Tombol Freelook 360",
        "Fullbright (Cahaya Malam)",
        "No HurtCam (Anti Goyang)",
        "HUD FPS & CPS Counter",
        "HUD Armor & Potion",
        "HUD Touchstrokes (WASD)",
        "HUD Combo & Reach",
        "Tombol 1-Tap F5 Camera",
        "HUD Auto-Sprint Badge"
    };

    private static boolean loaded = false;

    static {
        try {
            System.loadLibrary("gamexclient");
            loaded = true;
        } catch (Throwable t) {
            loaded = false;
        }
    }

    public static boolean isNativeLoaded() {
        return loaded;
    }

    public static native int nativeAttachEngine(String soPath);
    public static native void nativeSetFeatureToggle(int featureId, boolean enabled);
    public static native boolean nativeGetFeatureToggle(int featureId);
    public static native void nativeSetTargetFps(int fps);
    public static native int nativeGetTargetFps();
    public static native void nativeSetZoomState(boolean active, float multiplier);
    public static native float nativeTickEffectiveFov(float baseFov, float dt);
    public static native void nativeSetFreelookDelta(boolean active, float dYaw, float dPitch);
    public static native String nativeGetEngineDiagnostic();
}
