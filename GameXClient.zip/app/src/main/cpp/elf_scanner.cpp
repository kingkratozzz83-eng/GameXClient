#include "gamex_core.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dlfcn.h>
#include <unistd.h>
#include <sys/mman.h>

#ifdef __ANDROID__
#include <android/log.h>
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "GameXNative", __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "GameXNative", __VA_ARGS__)
#else
#define LOGI(...) printf(__VA_ARGS__)
#define LOGE(...) fprintf(stderr, __VA_ARGS__)
#endif

namespace gamex {

ClientConfig gConfig;

uintptr_t findLibraryBase(const char* soname) {
    FILE* fp = fopen("/proc/self/maps", "r");
    if (!fp) return 0;

    char line[512];
    uintptr_t base = 0;
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, soname)) {
            uintptr_t start = 0;
            if (sscanf(line, "%lx-", &start) == 1) {
                base = start;
                break;
            }
        }
    }
    fclose(fp);
    return base;
}

bool patchMemoryFloat(uintptr_t addr, float value) {
    if (addr == 0) return false;
    long pageSize = sysconf(_SC_PAGESIZE);
    uintptr_t pageStart = addr & ~(pageSize - 1);
    if (mprotect((void*)pageStart, pageSize, PROT_READ | PROT_WRITE | PROT_EXEC) != 0) {
        return false;
    }
    *(volatile float*)addr = value;
    __builtin___clear_cache((char*)pageStart, (char*)(pageStart + pageSize));
    mprotect((void*)pageStart, pageSize, PROT_READ | PROT_EXEC);
    return true;
}

bool installArm64Trampoline(uintptr_t targetAddr, void* detourFunc, void** origFuncOut) {
#if defined(__aarch64__)
    if (targetAddr == 0 || detourFunc == nullptr) return false;
    long pageSize = sysconf(_SC_PAGESIZE);
    uintptr_t pageStart = targetAddr & ~(pageSize - 1);

    void* gateway = mmap(nullptr, pageSize, PROT_READ | PROT_WRITE | PROT_EXEC,
                         MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (gateway == MAP_FAILED) return false;

    uint32_t* src = reinterpret_cast<uint32_t*>(targetAddr);
    uint32_t* dst = reinterpret_cast<uint32_t*>(gateway);

    dst[0] = src[0];
    dst[1] = src[1];
    dst[2] = src[2];
    dst[3] = src[3];

    dst[4] = 0x58000050;
    dst[5] = 0xD61F0200;
    *reinterpret_cast<uint64_t*>(&dst[6]) = static_cast<uint64_t>(targetAddr + 16);
    __builtin___clear_cache((char*)gateway, (char*)gateway + 32);

    if (origFuncOut) {
        *origFuncOut = gateway;
    }

    if (mprotect((void*)pageStart, pageSize * 2, PROT_READ | PROT_WRITE | PROT_EXEC) != 0) {
        return false;
    }

    src[0] = 0x58000050;
    src[1] = 0xD61F0200;
    *reinterpret_cast<uint64_t*>(&src[2]) = reinterpret_cast<uint64_t>(detourFunc);

    __builtin___clear_cache((char*)targetAddr, (char*)(targetAddr + 16));
    mprotect((void*)pageStart, pageSize * 2, PROT_READ | PROT_EXEC);
    return true;
#else
    (void)targetAddr;
    (void)detourFunc;
    (void)origFuncOut;
    return false;
#endif
}

float computeEffectiveFov(float vanillaFov, float deltaTime) {
    float targetMultiplier = (gConfig.smoothZoom.load() && gConfig.zoomActive.load())
                             ? gConfig.zoomMultiplier.load()
                             : 1.0f;
    float current = gConfig.currentZoomLerp.load();
    float speed = 10.0f * (deltaTime > 0.0f && deltaTime < 0.2f ? deltaTime : 0.016f);
    current += (targetMultiplier - current) * speed;
    if (current < 1.0f) current = 1.0f;
    gConfig.currentZoomLerp.store(current);
    return vanillaFov / current;
}

float computeEffectiveGamma(float vanillaGamma) {
    if (gConfig.fullbright.load()) {
        return 16.0f;
    }
    return vanillaGamma;
}

int attachToMinecraftEngine(const char* mcpeSoPath) {
    int resolvedCount = 0;
    void* handle = dlopen("libminecraftpe.so", RTLD_LAZY | RTLD_NOLOAD);
    (void)mcpeSoPath;

    uintptr_t base = findLibraryBase("libminecraftpe.so");
    if (base != 0) {
        gConfig.mcpeBaseAddr.store(base);
        gConfig.mcpeLoaded.store(true);
        resolvedCount++;
        LOGI("libminecraftpe.so ditemukan di memori pada base: 0x%lx", (unsigned long)base);
    }

    if (handle) {
        void* symMain = dlsym(handle, "android_main");
        void* symJni = dlsym(handle, "JNI_OnLoad");
        void* symCreate = dlsym(handle, "ANativeActivity_onCreate");
        if (symMain) resolvedCount++;
        if (symJni) resolvedCount++;
        if (symCreate) resolvedCount++;
    }

    void* eglHandle = dlopen("libEGL.so", RTLD_LAZY | RTLD_NOLOAD);
    if (eglHandle) {
        using EglSwapIntervalFn = int (*)(void*, int);
        auto pEglSwapInterval = reinterpret_cast<EglSwapIntervalFn>(dlsym(eglHandle, "eglSwapInterval"));
        if (pEglSwapInterval) {
            resolvedCount++;
        }
    }

    gConfig.hookedSymbolsCount.store(resolvedCount);
    return resolvedCount;
}

} // namespace gamex
