package com.dodos.gamexclient;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class McpePackageExtractor {
    public static final String MCPE_PACKAGE = "com.mojang.minecraftpe";
    public static final String LEVI_PACKAGE = "org.levimc.launcher";

    public static class McpeEnvironment {
        public boolean installed;
        public boolean leviInstalled;
        public String versionName = "Tidak Terdeteksi";
        public long versionCode = 0;
        public String baseApkPath = "";
        public List<String> splitApkPaths = new ArrayList<>();
    }

    public static McpeEnvironment inspect(Context context) {
        McpeEnvironment env = new McpeEnvironment();
        PackageManager pm = context.getPackageManager();
        try {
            PackageInfo pkgInfo = pm.getPackageInfo(MCPE_PACKAGE, 0);
            ApplicationInfo appInfo = pm.getApplicationInfo(MCPE_PACKAGE, 0);

            env.installed = true;
            env.versionName = pkgInfo.versionName != null ? pkgInfo.versionName : "1.21+";
            env.versionCode = pkgInfo.getLongVersionCode();
            env.baseApkPath = appInfo.sourceDir;

            if (appInfo.splitSourceDirs != null) {
                for (String split : appInfo.splitSourceDirs) {
                    env.splitApkPaths.add(split);
                }
            }
        } catch (Throwable t) {
            env.installed = false;
        }

        try {
            pm.getPackageInfo(LEVI_PACKAGE, 0);
            env.leviInstalled = true;
        } catch (Throwable t) {
            env.leviInstalled = false;
        }
        return env;
    }

    public static boolean launchMinecraftApp(Context context) {
        try {
            PackageManager pm = context.getPackageManager();
            // Jika LeviLauncher terinstal, utamakan atau beri opsi karena mendukung injeksi .so penuh
            Intent launchIntent = pm.getLaunchIntentForPackage(MCPE_PACKAGE);
            if (launchIntent == null) {
                launchIntent = new Intent(Intent.ACTION_MAIN);
                launchIntent.addCategory(Intent.CATEGORY_LAUNCHER);
                launchIntent.setComponent(new ComponentName(MCPE_PACKAGE, "com.mojang.minecraftpe.MainActivity"));
            }
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            context.startActivity(launchIntent);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    public static File exportStandaloneLevipack(Context context) {
        try {
            File nativeDir = new File(context.getApplicationInfo().nativeLibraryDir);
            File ourSo = new File(nativeDir, "libgamexclient.so");
            File outDir = context.getExternalFilesDir(null);
            if (outDir == null) outDir = context.getFilesDir();
            File packFile = new File(outDir, "GameXClient-Mod-arm64.levipack");

            try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(packFile))) {
                String manifest = "{\n"
                        + "  \"format_version\": 1,\n"
                        + "  \"id\": \"gamexclient\",\n"
                        + "  \"name\": \"GameXClient Native Pack\",\n"
                        + "  \"version\": \"1.2.0\",\n"
                        + "  \"author\": \"dodosadventure\",\n"
                        + "  \"entry\": \"libgamexclient.so\",\n"
                        + "  \"platform\": \"android-arm64-v8a\"\n"
                        + "}\n";
                zos.putNextEntry(new ZipEntry("manifest.json"));
                zos.write(manifest.getBytes(StandardCharsets.UTF_8));
                zos.closeEntry();

                if (ourSo.exists()) {
                    zos.putNextEntry(new ZipEntry("libgamexclient.so"));
                    try (FileInputStream fis = new FileInputStream(ourSo)) {
                        byte[] buf = new byte[32768];
                        int len;
                        while ((len = fis.read(buf)) > 0) {
                            zos.write(buf, 0, len);
                        }
                    }
                    zos.closeEntry();
                }
            }
            return packFile;
        } catch (Exception e) {
            return null;
        }
    }
}
