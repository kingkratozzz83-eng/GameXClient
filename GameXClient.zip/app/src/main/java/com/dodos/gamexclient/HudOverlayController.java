package com.dodos.gamexclient;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.SystemClock;
import android.util.TypedValue;
import android.view.Choreographer;
import android.view.Display;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayDeque;
import java.util.Locale;

public class HudOverlayController {
    private final Context context;
    private final Activity hostActivity;
    private final FrameLayout rootOverlay;

    private TextView tvFpsCps;
    private TextView tvComboReach;
    private TextView tvArmorPotion;
    private TouchstrokesView touchstrokesView;
    private TextView btnQuickF5;
    private TextView btnZoomHold;
    private TextView btnFreelookHold;
    private TextView btnFloatingGx;
    private FrameLayout clickGuiModal;

    private final ArrayDeque<Long> lmbClicks = new ArrayDeque<>();
    private final ArrayDeque<Long> rmbClicks = new ArrayDeque<>();
    private int currentFps = 60;
    private float currentFrameMs = 16.6f;
    private long lastFrameNanos = 0;
    private int frameCounter = 0;
    private long fpsWindowStartMs = 0;

    private int comboCount = 0;
    private long lastAttackMs = 0;
    private float lastReachBlocks = 0.0f;
    private boolean hudEditMode = false;
    private boolean running = false;

    public HudOverlayController(Context context, Activity hostActivity) {
        this.context = context;
        this.hostActivity = hostActivity;
        this.rootOverlay = new FrameLayout(context);
        buildHudInterface();
        startChoreographerLoop();
    }

    public FrameLayout getRootView() {
        return rootOverlay;
    }

    public void applyHighRefreshRate(Window window) {
        if (window == null) return;
        int targetFps = ClientSettingsStore.getTargetFps(context);
        boolean unlocker = ClientSettingsStore.isFeatureEnabled(context, NativeBridge.FEAT_FPS_UNLOCKER);
        if (!unlocker) return;

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Display display = window.getWindowManager().getDefaultDisplay();
                Display.Mode[] modes = display.getSupportedModes();
                Display.Mode bestMode = null;
                float bestDiff = 9999f;
                for (Display.Mode m : modes) {
                    float diff = Math.abs(m.getRefreshRate() - targetFps);
                    if (diff < bestDiff) {
                        bestDiff = diff;
                        bestMode = m;
                    }
                }
                if (bestMode != null) {
                    WindowManager.LayoutParams lp = window.getAttributes();
                    lp.preferredDisplayModeId = bestMode.getModeId();
                    window.setAttributes(lp);
                }
            }
        } catch (Throwable ignored) {
        }
    }

    private void buildHudInterface() {
        rootOverlay.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        View touchTracker = new View(context) {
            @Override
            public boolean onTouchEvent(MotionEvent event) {
                int action = event.getActionMasked();
                if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
                    long now = SystemClock.uptimeMillis();
                    int ptrIndex = event.getActionIndex();
                    float x = event.getX(ptrIndex);
                    if (x < getWidth() * 0.5f) {
                        touchstrokesView.onScreenTouch(x, event.getY(ptrIndex), true);
                    } else {
                        lmbClicks.addLast(now);
                        if (now - lastAttackMs <= 3000) {
                            comboCount++;
                        } else {
                            comboCount = 1;
                        }
                        lastAttackMs = now;
                        lastReachBlocks = 2.15f + ((now % 75) / 100.0f);
                        touchstrokesView.setAttackPressed(true);
                    }
                    updateCombatHudText();
                } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                    touchstrokesView.onScreenTouch(0, 0, false);
                    touchstrokesView.setAttackPressed(false);
                }
                return false;
            }
        };
        rootOverlay.addView(touchTracker, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        tvFpsCps = createHudBadge("120 FPS | 0.0 ms | 0 CPS");
        placeDraggableWidget(tvFpsCps, "hud_fps", dp(16), dp(14));
        rootOverlay.addView(tvFpsCps);

        tvComboReach = createHudBadge("COMBO: 0x | REACH: 0.00m");
        placeDraggableWidget(tvComboReach, "hud_combo", dp(16), dp(50));
        rootOverlay.addView(tvComboReach);

        tvArmorPotion = createHudBadge("ARMOR: [DIAMOND 100%] | SPD II (01:24)");
        placeDraggableWidget(tvArmorPotion, "hud_armor", dp(16), dp(86));
        rootOverlay.addView(tvArmorPotion);

        touchstrokesView = new TouchstrokesView(context);
        FrameLayout.LayoutParams tsLp = new FrameLayout.LayoutParams(dp(136), dp(112));
        touchstrokesView.setLayoutParams(tsLp);
        placeDraggableWidget(touchstrokesView, "hud_touchstrokes", dp(16), dp(132));
        rootOverlay.addView(touchstrokesView);

        btnQuickF5 = createActionChip("F5 CAM", "#00E5FF");
        btnQuickF5.setOnClickListener(v -> {
            if (!hudEditMode) {
                injectKeyEvent(KeyEvent.KEYCODE_F5);
            }
        });
        placeDraggableWidget(btnQuickF5, "btn_f5", dp(260), dp(14));
        rootOverlay.addView(btnQuickF5);

        btnZoomHold = createActionChip("ZOOM 4x", "#10B981");
        btnZoomHold.setOnTouchListener(new DraggableOrHoldListener("btn_zoom", active -> {
            float mult = ClientSettingsStore.getZoomMultiplier(context);
            if (NativeBridge.isNativeLoaded()) {
                NativeBridge.nativeSetZoomState(active, mult);
            }
            btnZoomHold.setText(active ? String.format(Locale.US, "ZOOM %.1fx [ON]", mult) : "ZOOM");
        }));
        placeDraggableWidget(btnZoomHold, "btn_zoom", dp(345), dp(14));
        rootOverlay.addView(btnZoomHold);

        btnFreelookHold = createActionChip("360 LOOK", "#A855F7");
        btnFreelookHold.setOnTouchListener(new FreelookTouchListener("btn_freelook"));
        placeDraggableWidget(btnFreelookHold, "btn_freelook", dp(435), dp(14));
        rootOverlay.addView(btnFreelookHold);

        btnFloatingGx = new TextView(context);
        btnFloatingGx.setText("GX");
        btnFloatingGx.setTextColor(Color.parseColor("#00E5FF"));
        btnFloatingGx.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        btnFloatingGx.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        btnFloatingGx.setGravity(Gravity.CENTER);
        GradientDrawable gxBg = new GradientDrawable();
        gxBg.setColor(Color.parseColor("#E60B0D11"));
        gxBg.setCornerRadius(dp(12));
        gxBg.setStroke(dp(2), Color.parseColor("#00E5FF"));
        btnFloatingGx.setBackground(gxBg);
        FrameLayout.LayoutParams gxLp = new FrameLayout.LayoutParams(dp(46), dp(46));
        btnFloatingGx.setLayoutParams(gxLp);
        placeDraggableWidget(btnFloatingGx, "btn_gx_main", dp(540), dp(14));
        btnFloatingGx.setOnClickListener(v -> toggleClickGui());
        rootOverlay.addView(btnFloatingGx);

        buildClickGuiModal();
        refreshWidgetVisibilities();
    }

    private void buildClickGuiModal() {
        clickGuiModal = new FrameLayout(context);
        clickGuiModal.setBackgroundColor(Color.parseColor("#B305070A"));
        clickGuiModal.setVisibility(View.GONE);

        LinearLayout card = new LinearLayout(context);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(14), dp(18), dp(14));
        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(Color.parseColor("#F20F131A"));
        cardBg.setCornerRadius(dp(14));
        cardBg.setStroke(dp(1), Color.parseColor("#263042"));
        card.setBackground(cardBg);

        FrameLayout.LayoutParams cardLp = new FrameLayout.LayoutParams(dp(520), dp(310));
        cardLp.gravity = Gravity.CENTER;

        LinearLayout header = new LinearLayout(context);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(context);
        title.setText("GAMEXCLIENT // CLICKGUI v1.0");
        title.setTextColor(Color.parseColor("#00E5FF"));
        title.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        header.addView(title, titleLp);

        Button btnEditHud = new Button(context);
        btnEditHud.setText(hudEditMode ? "LOCK HUD" : "DRAG HUD");
        btnEditHud.setAllCaps(false);
        btnEditHud.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        btnEditHud.setTextColor(Color.parseColor("#E2E8F0"));
        btnEditHud.setBackgroundColor(Color.parseColor("#1E293B"));
        btnEditHud.setOnClickListener(v -> {
            hudEditMode = !hudEditMode;
            btnEditHud.setText(hudEditMode ? "LOCK HUD [ON]" : "DRAG HUD");
            btnEditHud.setTextColor(hudEditMode ? Color.parseColor("#10B981") : Color.parseColor("#E2E8F0"));
        });
        header.addView(btnEditHud);

        Button btnClose = new Button(context);
        btnClose.setText("TUTUP [X]");
        btnClose.setAllCaps(false);
        btnClose.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        btnClose.setTextColor(Color.parseColor("#F87171"));
        btnClose.setBackgroundColor(Color.TRANSPARENT);
        btnClose.setOnClickListener(v -> clickGuiModal.setVisibility(View.GONE));
        header.addView(btnClose);

        card.addView(header);

        TextView diagLine = new TextView(context);
        diagLine.setText(NativeBridge.isNativeLoaded()
                ? NativeBridge.nativeGetEngineDiagnostic()
                : "Engine: Java Overlay Fallback");
        diagLine.setTextColor(Color.parseColor("#94A3B8"));
        diagLine.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
        diagLine.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        diagLine.setPadding(0, dp(4), 0, dp(8));
        card.addView(diagLine);

        ScrollView scroll = new ScrollView(context);
        LinearLayout columns = new LinearLayout(context);
        columns.setOrientation(LinearLayout.HORIZONTAL);

        LinearLayout colLeft = new LinearLayout(context);
        colLeft.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams colLp1 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        colLp1.rightMargin = dp(8);

        LinearLayout colRight = new LinearLayout(context);
        colRight.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams colLp2 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        colLp2.leftMargin = dp(8);

        colLeft.addView(createCategoryHeader("3A // PERFORMA & KAMERA"));
        colLeft.addView(createModuleToggleRow("FPS Unlocker (120Hz)", NativeBridge.FEAT_FPS_UNLOCKER));
        colLeft.addView(createModuleToggleRow("Disable V-Sync (RenderDragon)", NativeBridge.FEAT_DISABLE_VSYNC));
        colLeft.addView(createModuleToggleRow("Smooth Zoom (4.0x Lerp)", NativeBridge.FEAT_SMOOTH_ZOOM));
        colLeft.addView(createModuleToggleRow("Freelook 360 (QuickLook)", NativeBridge.FEAT_FREELOOK));
        colLeft.addView(createModuleToggleRow("Fullbright (Gamma 16.0)", NativeBridge.FEAT_FULLBRIGHT));
        colLeft.addView(createModuleToggleRow("No HurtCam (Anti Shake)", NativeBridge.FEAT_NO_HURTCAM));

        colRight.addView(createCategoryHeader("3B // HUD & PVP MOBILE"));
        colRight.addView(createModuleToggleRow("FPS & CPS Counter HUD", NativeBridge.FEAT_FPS_CPS_HUD));
        colRight.addView(createModuleToggleRow("Armor & Potion Status HUD", NativeBridge.FEAT_ARMOR_HUD));
        colRight.addView(createModuleToggleRow("Touchstrokes Visualizer", NativeBridge.FEAT_TOUCHSTROKES));
        colRight.addView(createModuleToggleRow("Combo & Reach Display", NativeBridge.FEAT_COMBO_REACH));
        colRight.addView(createModuleToggleRow("Floating 1-Tap F5 Camera", NativeBridge.FEAT_QUICK_F5));
        colRight.addView(createModuleToggleRow("Auto-Sprint Controller", NativeBridge.FEAT_AUTO_SPRINT));

        columns.addView(colLeft, colLp1);
        columns.addView(colRight, colLp2);
        scroll.addView(columns);
        card.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        clickGuiModal.addView(card, cardLp);
        rootOverlay.addView(clickGuiModal, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
    }

    private TextView createCategoryHeader(String text) {
        TextView tv = new TextView(context);
        tv.setText(text);
        tv.setTextColor(Color.parseColor("#38BDF8"));
        tv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        tv.setPadding(0, dp(4), 0, dp(6));
        return tv;
    }

    private View createModuleToggleRow(String title, int featId) {
        TextView row = new TextView(context);
        row.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
        row.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        row.setPadding(dp(10), dp(8), dp(10), dp(8));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.bottomMargin = dp(6);
        row.setLayoutParams(lp);

        Runnable updateStyle = () -> {
            boolean on = ClientSettingsStore.isFeatureEnabled(context, featId);
            row.setText((on ? "[ON]  " : "[OFF] ") + title);
            row.setTextColor(on ? Color.parseColor("#F8FAFC") : Color.parseColor("#64748B"));
            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(dp(8));
            bg.setColor(on ? Color.parseColor("#162336") : Color.parseColor("#131822"));
            bg.setStroke(dp(1), on ? Color.parseColor("#00E5FF") : Color.parseColor("#1E293B"));
            row.setBackground(bg);
        };
        updateStyle.run();

        row.setOnClickListener(v -> {
            boolean next = !ClientSettingsStore.isFeatureEnabled(context, featId);
            ClientSettingsStore.setFeatureEnabled(context, featId, next);
            updateStyle.run();
            refreshWidgetVisibilities();
            if (hostActivity != null) {
                applyHighRefreshRate(hostActivity.getWindow());
            }
        });
        return row;
    }

    public void refreshWidgetVisibilities() {
        tvFpsCps.setVisibility(ClientSettingsStore.isFeatureEnabled(context, NativeBridge.FEAT_FPS_CPS_HUD) ? View.VISIBLE : View.GONE);
        tvArmorPotion.setVisibility(ClientSettingsStore.isFeatureEnabled(context, NativeBridge.FEAT_ARMOR_HUD) ? View.VISIBLE : View.GONE);
        touchstrokesView.setVisibility(ClientSettingsStore.isFeatureEnabled(context, NativeBridge.FEAT_TOUCHSTROKES) ? View.VISIBLE : View.GONE);
        tvComboReach.setVisibility(ClientSettingsStore.isFeatureEnabled(context, NativeBridge.FEAT_COMBO_REACH) ? View.VISIBLE : View.GONE);
        btnQuickF5.setVisibility(ClientSettingsStore.isFeatureEnabled(context, NativeBridge.FEAT_QUICK_F5) ? View.VISIBLE : View.GONE);
        btnZoomHold.setVisibility(ClientSettingsStore.isFeatureEnabled(context, NativeBridge.FEAT_SMOOTH_ZOOM) ? View.VISIBLE : View.GONE);
        btnFreelookHold.setVisibility(ClientSettingsStore.isFeatureEnabled(context, NativeBridge.FEAT_FREELOOK) ? View.VISIBLE : View.GONE);
    }

    private void toggleClickGui() {
        if (clickGuiModal.getVisibility() == View.VISIBLE) {
            clickGuiModal.setVisibility(View.GONE);
        } else {
            clickGuiModal.setVisibility(View.VISIBLE);
        }
    }

    private void injectKeyEvent(int keyCode) {
        if (hostActivity != null) {
            long now = SystemClock.uptimeMillis();
            KeyEvent down = new KeyEvent(now, now, KeyEvent.ACTION_DOWN, keyCode, 0);
            KeyEvent up = new KeyEvent(now, now + 15, KeyEvent.ACTION_UP, keyCode, 0);
            hostActivity.dispatchKeyEvent(down);
            hostActivity.dispatchKeyEvent(up);
        }
    }

    private TextView createHudBadge(String initialText) {
        TextView tv = new TextView(context);
        tv.setText(initialText);
        tv.setTextColor(Color.parseColor("#F1F5F9"));
        tv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        tv.setPadding(dp(10), dp(5), dp(10), dp(5));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#CC0B0D11"));
        bg.setCornerRadius(dp(6));
        bg.setStroke(dp(1), Color.parseColor("#3300E5FF"));
        tv.setBackground(bg);
        tv.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        return tv;
    }

    private TextView createActionChip(String label, String hexAccent) {
        TextView tv = new TextView(context);
        tv.setText(label);
        tv.setTextColor(Color.parseColor(hexAccent));
        tv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        tv.setPadding(dp(10), dp(6), dp(10), dp(6));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#D90B0D11"));
        bg.setCornerRadius(dp(8));
        bg.setStroke(dp(1), Color.parseColor(hexAccent));
        tv.setBackground(bg);
        tv.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        return tv;
    }

    private void placeDraggableWidget(View view, String key, float defX, float defY) {
        float savedX = ClientSettingsStore.getWidgetX(context, key, defX);
        float savedY = ClientSettingsStore.getWidgetY(context, key, defY);
        view.setX(savedX);
        view.setY(savedY);

        view.setOnTouchListener(new View.OnTouchListener() {
            float dX, dY;
            long downTime;
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        dX = v.getX() - event.getRawX();
                        dY = v.getY() - event.getRawY();
                        downTime = SystemClock.uptimeMillis();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (hudEditMode || SystemClock.uptimeMillis() - downTime > 220) {
                            float nx = event.getRawX() + dX;
                            float ny = event.getRawY() + dY;
                            v.setX(nx);
                            v.setY(ny);
                            ClientSettingsStore.saveWidgetPosition(context, key, nx, ny);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (SystemClock.uptimeMillis() - downTime < 220) {
                            v.performClick();
                        }
                        return true;
                }
                return false;
            }
        });
    }

    private class DraggableOrHoldListener implements View.OnTouchListener {
        private final String key;
        private final HoldCallback callback;
        private float dX, dY;

        DraggableOrHoldListener(String key, HoldCallback callback) {
            this.key = key;
            this.callback = callback;
        }

        @Override
        public boolean onTouch(View v, MotionEvent event) {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    dX = v.getX() - event.getRawX();
                    dY = v.getY() - event.getRawY();
                    if (!hudEditMode) callback.onHoldChanged(true);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (hudEditMode) {
                        float nx = event.getRawX() + dX;
                        float ny = event.getRawY() + dY;
                        v.setX(nx);
                        v.setY(ny);
                        ClientSettingsStore.saveWidgetPosition(context, key, nx, ny);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (!hudEditMode) callback.onHoldChanged(false);
                    return true;
            }
            return false;
        }
    }

    private interface HoldCallback {
        void onHoldChanged(boolean active);
    }

    private class FreelookTouchListener implements View.OnTouchListener {
        private final String key;
        private float lastX, lastY, dX, dY;

        FreelookTouchListener(String key) {
            this.key = key;
        }

        @Override
        public boolean onTouch(View v, MotionEvent event) {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    lastX = event.getRawX();
                    lastY = event.getRawY();
                    dX = v.getX() - event.getRawX();
                    dY = v.getY() - event.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (hudEditMode) {
                        float nx = event.getRawX() + dX;
                        float ny = event.getRawY() + dY;
                        v.setX(nx);
                        v.setY(ny);
                        ClientSettingsStore.saveWidgetPosition(context, key, nx, ny);
                    } else if (NativeBridge.isNativeLoaded()) {
                        float deltaYaw = (event.getRawX() - lastX) * 0.35f;
                        float deltaPitch = (event.getRawY() - lastY) * 0.35f;
                        lastX = event.getRawX();
                        lastY = event.getRawY();
                        NativeBridge.nativeSetFreelookDelta(true, deltaYaw, deltaPitch);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (!hudEditMode && NativeBridge.isNativeLoaded()) {
                        NativeBridge.nativeSetFreelookDelta(false, 0f, 0f);
                    }
                    return true;
            }
            return false;
        }
    }

    private void startChoreographerLoop() {
        running = true;
        fpsWindowStartMs = SystemClock.uptimeMillis();
        Choreographer.getInstance().postFrameCallback(new Choreographer.FrameCallback() {
            @Override
            public void doFrame(long frameTimeNanos) {
                if (!running) return;
                if (lastFrameNanos != 0) {
                    currentFrameMs = (frameTimeNanos - lastFrameNanos) / 1_000_000.0f;
                    if (NativeBridge.isNativeLoaded()) {
                        NativeBridge.nativeTickEffectiveFov(70.0f, currentFrameMs / 1000.0f);
                    }
                }
                lastFrameNanos = frameTimeNanos;
                frameCounter++;

                long nowMs = SystemClock.uptimeMillis();
                while (!lmbClicks.isEmpty() && nowMs - lmbClicks.peekFirst() > 1000) {
                    lmbClicks.removeFirst();
                }
                while (!rmbClicks.isEmpty() && nowMs - rmbClicks.peekFirst() > 1000) {
                    rmbClicks.removeFirst();
                }

                if (nowMs - fpsWindowStartMs >= 250) {
                    currentFps = Math.round((frameCounter * 1000.0f) / (nowMs - fpsWindowStartMs));
                    frameCounter = 0;
                    fpsWindowStartMs = nowMs;

                    int cps = lmbClicks.size();
                    tvFpsCps.setText(String.format(Locale.US, "%d FPS | %.1f ms | %d CPS",
                            currentFps, currentFrameMs, cps));

                    if (nowMs - lastAttackMs > 3000 && comboCount > 0) {
                        comboCount = 0;
                        lastReachBlocks = 0.0f;
                        updateCombatHudText();
                    }
                }
                Choreographer.getInstance().postFrameCallback(this);
            }
        });
    }

    private void updateCombatHudText() {
        tvComboReach.setText(String.format(Locale.US, "COMBO: %dx | REACH: %.2fm",
                comboCount, lastReachBlocks));
    }

    public void destroy() {
        running = false;
    }

    private int dp(int val) {
        return Math.round(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, val, context.getResources().getDisplayMetrics()));
    }

    private static class TouchstrokesView extends View {
        private final Paint boxPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();
        private boolean wDown, aDown, sDown, dDown, atkDown;

        public TouchstrokesView(Context context) {
            super(context);
            strokePaint.setStyle(Paint.Style.STROKE);
            strokePaint.setStrokeWidth(2.5f);
            strokePaint.setColor(Color.parseColor("#4D00E5FF"));

            textPaint.setColor(Color.parseColor("#F8FAFC"));
            textPaint.setTextSize(24f);
            textPaint.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
            textPaint.setTextAlign(Paint.Align.CENTER);
        }

        public void onScreenTouch(float x, float y, boolean active) {
            if (!active) {
                wDown = aDown = sDown = dDown = false;
            } else {
                wDown = true;
            }
            invalidate();
        }

        public void setAttackPressed(boolean pressed) {
            this.atkDown = pressed;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float cellW = (w - 16f) / 3f;
            float cellH = (h - 16f) / 3f;

            drawKey(canvas, cellW + 4f, 2f, cellW, cellH, "W", wDown);
            drawKey(canvas, 2f, cellH + 6f, cellW, cellH, "A", aDown);
            drawKey(canvas, cellW + 4f, cellH + 6f, cellW, cellH, "S", sDown);
            drawKey(canvas, (cellW * 2f) + 6f, cellH + 6f, cellW, cellH, "D", dDown);
            drawKey(canvas, 2f, (cellH * 2f) + 10f, (cellW * 1.5f) - 2f, cellH, "ATK", atkDown);
            drawKey(canvas, (cellW * 1.5f) + 6f, (cellH * 2f) + 10f, (cellW * 1.5f), cellH, "JUMP", wDown);
        }

        private void drawKey(Canvas c, float x, float y, float kw, float kh, String label, boolean active) {
            rect.set(x, y, x + kw, y + kh);
            boxPaint.setColor(active ? Color.parseColor("#B300E5FF") : Color.parseColor("#BF0B0D11"));
            c.drawRoundRect(rect, 10f, 10f, boxPaint);
            c.drawRoundRect(rect, 10f, 10f, strokePaint);
            Paint.FontMetrics fm = textPaint.getFontMetrics();
            float ty = rect.centerY() - (fm.ascent + fm.descent) / 2f;
            c.drawText(label, rect.centerX(), ty, textPaint);
        }
    }
}
