# GameXClient v1.2 — Minecraft Bedrock Android Client (Anti-Kill Foreground HUD + Native .so)

Pembaruan v1.2 memperbaiki:
1. **HUD Tidak Hilang Saat Masuk Game (`startForeground` + `WakeLock` + `stopWithTask="false"`):** `OverlayHudService` kini berjalan sebagai *Foreground Service* resmi dengan notifikasi persisten dan pengecualian baterai sehingga sistem Android (termasuk OriginOS/FuntouchOS di iQOO) tidak mematikan HUD saat Minecraft berjalan.
2. **Fitur Berfungsi Nyata di Dalam Minecraft (`FLAG_WATCH_OUTSIDE_TOUCH`):**
   - **CPS & Combo/Reach Counter + Touchstrokes:** Mendeteksi setiap sentuhan di layar Minecraft secara *real-time* lewat sensor `MotionEvent.ACTION_OUTSIDE` tanpa menghalangi sentuhan ke dalam game.
   - **Fullbright Nyata:** Mengubah kecerahan layar perangkat ke 100% (`screenBrightness = 1.0f`) ditambah filter gamma terang yang tembus sentuhan.
   - **Custom PvP Crosshair (+) & Tactical Zoom Scope (4x):** Menampilkan crosshair PvP presisi, *hitmarker* merah saat menyerang, dan bidikan *scope* saat tombol Zoom ditekan.
   - **120Hz Refresh Rate Lock:** Meminta mode layar 120Hz langsung pada *WindowManager* selama HUD tampil di atas Minecraft.
