package com.dodos.gamexclient;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.SurfaceView;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;

public class GameHostActivity extends Activity {
    private HudOverlayController hudController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        );

        ClientSettingsStore.syncAllToNative(this);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#07090E"));

        SurfaceView gameSurface = new SurfaceView(this);
        root.addView(gameSurface, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        TextView engineBanner = new TextView(this);
        engineBanner.setTextColor(Color.parseColor("#94A3B8"));
        engineBanner.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        engineBanner.setPadding(32, 16, 32, 16);
        FrameLayout.LayoutParams bannerLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        bannerLp.gravity = Gravity.BOTTOM | Gravity.START;
        root.addView(engineBanner, bannerLp);

        hudController = new HudOverlayController(this, this);
        hudController.applyHighRefreshRate(getWindow());
        root.addView(hudController.getRootView());

        setContentView(root);

        McpePackageExtractor.McpeEnvironment env = McpePackageExtractor.inspectAndPrepare(this, true);
        if (env.installed && env.libMinecraftPeSo != null) {
            try {
                for (String dep : new String[]{"libc++_shared.so", "libfmod.so"}) {
                    java.io.File depFile = new java.io.File(env.extractedNativeDir, dep);
                    if (depFile.exists()) {
                        System.load(depFile.getAbsolutePath());
                    }
                }
                System.load(env.libMinecraftPeSo.getAbsolutePath());
                int hooks = NativeBridge.nativeAttachEngine(env.libMinecraftPeSo.getAbsolutePath());
                engineBanner.setText("GameXClient Host Active | MCPE " + env.versionName
                        + " | libminecraftpe.so loaded (Hooks=" + hooks + ") | Tekan [GX] untuk ClickGUI");

                if (getIntent().getBooleanExtra("bridge_launch", false)) {
                    Intent launchIntent = getPackageManager().getLaunchIntentForPackage(McpePackageExtractor.MCPE_PACKAGE);
                    if (launchIntent != null) {
                        startService(new Intent(this, OverlayHudService.class));
                        startActivity(launchIntent);
                    }
                }
            } catch (Throwable t) {
                engineBanner.setText("GameXClient Host | Mode Sandbox ClickGUI Aktif (" + t.getClass().getSimpleName() + ")");
            }
        } else {
            engineBanner.setText("GameXClient Sandbox Preview | Tekan tombol [GX] di kanan atas untuk membuka ClickGUI & uji semua fitur");
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (hudController != null) {
            hudController.destroy();
        }
    }
}
