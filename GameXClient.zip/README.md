# GameXClient — Minecraft Bedrock Android Native Client (ARM64 C++20)

Proyek mandiri **GameXClient** yang menggabungkan:
1. **Host Launcher & Overlay Engine (`com.dodos.gamexclient`)** bertema *Matte-Dark Obsidian*.
2. **Native C++20 Engine (`libgamexclient.so`)** yang dikompilasi menggunakan Android NDK & CMake untuk mengaitkan fungsi `libminecraftpe.so` serta mengekspor paket `.levipack` yang kompatibel dengan [LeviLauncher-Android](https://github.com/LiteLDev/LeviLauncher-Android).
3. **Paket Fitur 3C Lengkap (3A + 3B):**
   - **3A (Performa & Kamera):** FPS Unlocker (60/90/120/144 Hz + V-Sync Off), Smooth Zoom (4.0x Lerp), Freelook 360, Fullbright, dan No HurtCam.
   - **3B (HUD & PvP Mobile):** Real-Time FPS/CPS Counter, Armor & Potion Status HUD, Touchstrokes Visualizer, Combo & Reach Display, Floating 1-Tap F5 Perspective Toggle, dan Draggable HUD Layout Editor.
