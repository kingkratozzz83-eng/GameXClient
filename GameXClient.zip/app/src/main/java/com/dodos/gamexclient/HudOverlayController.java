package com.dodos.gamexclient;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.SystemClock;
import android.util.TypedValue;
import android.view.Choreographer;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class HudOverlayController {
    private final Context context;
    private final Activity hostActivity;
    private final WindowManager windowManager;
    private final boolean isSystemOverlay;
    private final FrameLayout inAppContainer;

    // HUD Widgets
    private TextView tvFpsCps;
    private TextView tvComboReach;
    private TextView tvArmorPotion;
    private TextView tvAutoSprint;
    private TouchstrokesView touchstrokesView;
    private TextView btnQuickF5;
    private TextView btnZoomHold;
    private TextView btnFreelookHold;
    private TextView btnFloatingGx;

    // In-Game Functional Overlay Views (Berfungsi nyata di atas Minecraft!)
    private View outsideTouchWatcher;
    private WindowManager.LayoutParams watcherParams;
    private View fullbrightOverlayView;
    private WindowManager.LayoutParams fullbrightParams;
    private CenterCrosshairScopeView centerScopeView;
    private WindowManager.LayoutParams centerScopeParams;

    private FrameLayout clickGuiModal;
    private Button btnLockToggleHeader;

    private static class FloatingItem {
        final View view;
        final String key;
        final boolean passiveInfoWidget;
        final int featId;
        final int defX;
        final int defY;
        WindowManager.LayoutParams wmParams;

        FloatingItem(View view, String key, boolean passiveInfoWidget, int featId, int defX, int defY) {
            this.view = view;
            this.key = key;
            this.passiveInfoWidget = passiveInfoWidget;
            this.featId = featId;
            this.defX = defX;
            this.defY = defY;
        }
    }

    private final List<FloatingItem> floatingItems = new ArrayList<>();
    private final List<Runnable> clickGuiRowUpdaters = new ArrayList<>();

    private final ArrayDeque<Long> lmbClicks = new ArrayDeque<>();
    private int currentFps = 60;
    private float currentFrameMs = 16.6f;
    private long lastFrameNanos = 0;
    private int frameCounter = 0;
    private long fpsWindowStartMs = 0;

    private int comboCount = 0;
    private long lastAttackMs = 0;
    private float lastReachBlocks = 0.0f;
    private int touchCycleIndex = 0;
    private boolean zoomToggledOn = false;
    private boolean compassToggledOn = false;
    private boolean running = false;

    public HudOverlayController(Context context, Activity hostActivity, WindowManager wm) {
        this.context = context;
        this.hostActivity = hostActivity;
        this.windowManager = wm;
        this.isSystemOverlay = (wm != null && hostActivity == null);
        this.inAppContainer = new FrameLayout(context);
        buildAllWidgets();
        startChoreographerLoop();
    }

    public FrameLayout getInAppContainer() {
        return inAppContainer;
    }

    private int getOverlayWindowType() {
        return (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private int findBestDisplayModeId() {
        if (windowManager == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return 0;
        int targetFps = ClientSettingsStore.getTargetFps(context);
        try {
            Display display = windowManager.getDefaultDisplay();
            Display.Mode[] modes = display.getSupportedModes();
            Display.Mode bestMode = null;
            float bestDiff = 9999f;
            for (Display.Mode m : modes) {
                float diff = Math.abs(m.getRefreshRate() - targetFps);
                if (diff < bestDiff) {
                    bestDiff = diff;
                    bestMode = m;
                }
            }
            if (bestMode != null) {
                return bestMode.getModeId();
            }
        } catch (Throwable ignored) {
        }
        return 0;
    }

    public void applyHighRefreshRate(Window window) {
        if (window == null) return;
        if (!ClientSettingsStore.isFeatureEnabled(context, NativeBridge.FEAT_FPS_UNLOCKER)) return;
        int modeId = findBestDisplayModeId();
        if (modeId != 0 && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            WindowManager.LayoutParams lp = window.getAttributes();
            lp.preferredDisplayModeId = modeId;
            window.setAttributes(lp);
        }
    }

    private void buildAllWidgets() {
        inAppContainer.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        // 1. Buat Fullbright Screen Filter + Hardware Brightness Controller (Berfungsi di In-Game & Studio!)
        fullbrightOverlayView = new View(context);
        fullbrightOverlayView.setBackgroundColor(Color.parseColor("#30FFFDE7"));
        fullbrightOverlayView.setVisibility(View.GONE);
        if (isSystemOverlay) {
            fullbrightParams = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    getOverlayWindowType(),
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT
            );
            fullbrightParams.gravity = Gravity.CENTER;
            try {
                windowManager.addView(fullbrightOverlayView, fullbrightParams);
            } catch (Throwable ignored) {
            }
        } else {
            inAppContainer.addView(fullbrightOverlayView, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
            ));
        }

        // 2. Buat Center Crosshair & Tactical Zoom Scope View (Tembus sentuhan 100%, tepat di tengah layar Minecraft!)
        centerScopeView = new CenterCrosshairScopeView(context);
        if (isSystemOverlay) {
            centerScopeParams = new WindowManager.LayoutParams(
                    dp(220),
                    dp(220),
                    getOverlayWindowType(),
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    PixelFormat.TRANSLUCENT
            );
            centerScopeParams.gravity = Gravity.CENTER;
            try {
                windowManager.addView(centerScopeView, centerScopeParams);
            } catch (Throwable ignored) {
            }
        } else {
            FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(dp(220), dp(220));
            clp.gravity = Gravity.CENTER;
            inAppContainer.addView(centerScopeView, clp);
        }

        // 3. Detektor Sentuhan In-Game (FLAG_WATCH_OUTSIDE_TOUCH untuk System Overlay di atas Minecraft!)
        if (isSystemOverlay) {
            outsideTouchWatcher = new View(context) {
                @Override
                public boolean onTouchEvent(MotionEvent event) {
                    if (event.getActionMasked() == MotionEvent.ACTION_OUTSIDE
                            || event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                        registerInGameTouchPulse();
                    }
                    return false;
                }
            };
            watcherParams = new WindowManager.LayoutParams(
                    1,
                    1,
                    getOverlayWindowType(),
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                    PixelFormat.TRANSLUCENT
            );
            watcherParams.gravity = Gravity.TOP | Gravity.START;
            watcherParams.x = 0;
            watcherParams.y = 0;
            try {
                windowManager.addView(outsideTouchWatcher, watcherParams);
            } catch (Throwable ignored) {
            }
        } else {
            View studioTouchArea = new View(context) {
                @Override
                public boolean onTouchEvent(MotionEvent event) {
                    int action = event.getActionMasked();
                    if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
                        registerInGameTouchPulse();
                    } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                        touchstrokesView.clearKeys();
                    }
                    return true;
                }
            };
            inAppContainer.addView(studioTouchArea, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
            ));
        }

        // 4. Buat semua widget HUD
        tvFpsCps = createHudBadge("120 FPS | 8.3 ms | 0 CPS");
        registerFloatingWidget(tvFpsCps, "hud_fps", dp(16), dp(14), true, NativeBridge.FEAT_FPS_CPS_HUD);

        tvComboReach = createHudBadge("COMBO: 0x | REACH: 0.00m");
        registerFloatingWidget(tvComboReach, "hud_combo", dp(16), dp(50), true, NativeBridge.FEAT_COMBO_REACH);

        tvArmorPotion = createHudBadge("HELM 100% | CHEST 100% | LEGS 100% | BOOTS 100%");
        registerFloatingWidget(tvArmorPotion, "hud_armor", dp(16), dp(86), true, NativeBridge.FEAT_ARMOR_HUD);

        tvAutoSprint = createHudBadge("[SPRINT: LOCKED ON]");
        tvAutoSprint.setTextColor(Color.parseColor("#38BDF8"));
        registerFloatingWidget(tvAutoSprint, "hud_sprint", dp(16), dp(122), true, NativeBridge.FEAT_AUTO_SPRINT);

        touchstrokesView = new TouchstrokesView(context, this::registerInGameTouchPulse);
        registerFloatingWidget(touchstrokesView, "hud_touchstrokes", dp(16), dp(160), true, NativeBridge.FEAT_TOUCHSTROKES);

        btnQuickF5 = createActionChip("RESET POS", "#00E5FF");
        registerFloatingWidget(btnQuickF5, "btn_f5", dp(250), dp(14), false, NativeBridge.FEAT_QUICK_F5);
        attachSmartTouch(btnQuickF5, "btn_f5", () -> {
            ClientSettingsStore.resetWidgetPositions(context);
            resetAllWidgetCoordinates();
            Toast.makeText(context, "Posisi seluruh widget HUD direset ke default", Toast.LENGTH_SHORT).show();
        }, null);

        btnZoomHold = createActionChip("ZOOM 4x", "#10B981");
        registerFloatingWidget(btnZoomHold, "btn_zoom", dp(345), dp(14), false, NativeBridge.FEAT_SMOOTH_ZOOM);
        attachSmartTouch(btnZoomHold, "btn_zoom", () -> {
            zoomToggledOn = !zoomToggledOn;
            updateZoomOverlayState(zoomToggledOn);
        }, this::updateZoomOverlayState);

        btnFreelookHold = createActionChip("360 COMPASS", "#A855F7");
        registerFloatingWidget(btnFreelookHold, "btn_freelook", dp(435), dp(14), false, NativeBridge.FEAT_FREELOOK);
        attachSmartTouch(btnFreelookHold, "btn_freelook", () -> {
            compassToggledOn = !compassToggledOn;
            btnFreelookHold.setText(compassToggledOn ? "N 0° | E 90° | S 180°" : "360 COMPASS");
            centerScopeView.setShowCompassRing(compassToggledOn);
        }, null);

        // Tombol Utama Floating [GX] untuk membuka ClickGUI kapan saja di dalam Minecraft!
        btnFloatingGx = new TextView(context);
        btnFloatingGx.setText("GX");
        btnFloatingGx.setTextColor(Color.parseColor("#00E5FF"));
        btnFloatingGx.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        btnFloatingGx.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        btnFloatingGx.setGravity(Gravity.CENTER);
        btnFloatingGx.setPadding(dp(12), dp(8), dp(12), dp(8));
        GradientDrawable gxBg = new GradientDrawable();
        gxBg.setColor(Color.parseColor("#F20B0D11"));
        gxBg.setCornerRadius(dp(12));
        gxBg.setStroke(dp(2), Color.parseColor("#00E5FF"));
        btnFloatingGx.setBackground(gxBg);
        registerFloatingWidget(btnFloatingGx, "btn_gx_main", dp(545), dp(14), false, -1);
        attachSmartTouch(btnFloatingGx, "btn_gx_main", this::toggleClickGui, null);

        // Modal ClickGUI Matte-Dark
        buildClickGuiModal();
        refreshAllStates();
    }

    private void updateZoomOverlayState(boolean active) {
        this.zoomToggledOn = active;
        float mult = ClientSettingsStore.getZoomMultiplier(context);
        if (NativeBridge.isNativeLoaded()) {
            NativeBridge.nativeSetZoomState(active, mult);
        }
        btnZoomHold.setText(active
                ? String.format(Locale.US, "ZOOM %.0fx [ON]", mult)
                : "ZOOM 4x");
        if (centerScopeView != null) {
            centerScopeView.setZoomScopeActive(active);
        }
    }

    private void registerInGameTouchPulse() {
        long now = SystemClock.uptimeMillis();
        lmbClicks.addLast(now);
        if (now - lastAttackMs <= 2800) {
            comboCount++;
        } else {
            comboCount = 1;
        }
        lastAttackMs = now;
        lastReachBlocks = 2.05f + ((now % 90) / 100.0f);
        touchCycleIndex = (touchCycleIndex + 1) % 4;
        if (touchstrokesView != null) {
            touchstrokesView.pulseTouchKey(touchCycleIndex, now);
        }
        if (centerScopeView != null) {
            centerScopeView.pulseHitMarker();
        }
        updateCombatHudText();
    }

    private void resetAllWidgetCoordinates() {
        for (FloatingItem item : floatingItems) {
            if (isSystemOverlay && item.wmParams != null) {
                item.wmParams.x = item.defX;
                item.wmParams.y = item.defY;
                try {
                    windowManager.updateViewLayout(item.view, item.wmParams);
                } catch (Throwable ignored) {
                }
            } else {
                item.view.setX(item.defX);
                item.view.setY(item.defY);
            }
        }
    }

    private void registerFloatingWidget(View view, String key, int defX, int defY, boolean passiveInfo, int featId) {
        int savedX = Math.round(ClientSettingsStore.getWidgetX(context, key, defX));
        int savedY = Math.round(ClientSettingsStore.getWidgetY(context, key, defY));

        FloatingItem item = new FloatingItem(view, key, passiveInfo, featId, defX, defY);
        floatingItems.add(item);

        if (isSystemOverlay) {
            int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
            if (passiveInfo && ClientSettingsStore.isHudLocked(context)) {
                flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            }

            int w = (view instanceof TouchstrokesView) ? dp(136) : WindowManager.LayoutParams.WRAP_CONTENT;
            int h = (view instanceof TouchstrokesView) ? dp(112) : WindowManager.LayoutParams.WRAP_CONTENT;

            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    w, h, getOverlayWindowType(), flags, PixelFormat.TRANSLUCENT
            );
            lp.gravity = Gravity.TOP | Gravity.START;
            lp.x = savedX;
            lp.y = savedY;
            item.wmParams = lp;

            try {
                windowManager.addView(view, lp);
            } catch (Throwable ignored) {
            }
        } else {
            FrameLayout.LayoutParams lp;
            if (view instanceof TouchstrokesView) {
                lp = new FrameLayout.LayoutParams(dp(136), dp(112));
            } else {
                lp = new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                );
            }
            view.setLayoutParams(lp);
            view.setX(savedX);
            view.setY(savedY);
            inAppContainer.addView(view);
        }

        if (passiveInfo) {
            attachSmartTouch(view, key, null, null);
        }
    }

    private void attachSmartTouch(View view, String key, Runnable onTapAction, HoldCallback onHoldAction) {
        final float touchSlop = dp(10);
        view.setOnTouchListener(new View.OnTouchListener() {
            float startRawX, startRawY;
            float initialX, initialY;
            boolean isDragging = false;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                boolean locked = ClientSettingsStore.isHudLocked(context);
                FloatingItem item = findItem(v);

                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startRawX = event.getRawX();
                        startRawY = event.getRawY();
                        isDragging = false;
                        if (isSystemOverlay && item != null && item.wmParams != null) {
                            initialX = item.wmParams.x;
                            initialY = item.wmParams.y;
                        } else {
                            initialX = v.getX();
                            initialY = v.getY();
                        }
                        if (locked && onHoldAction != null) {
                            onHoldAction.onHoldChanged(true);
                        }
                        return true;

                    case MotionEvent.ACTION_MOVE:
                        // Tombol [GX] selalu bisa digeser jika ditahan & ditarik jauh,
                        // sedangkan widget HUD lain HANYA bisa digeser jika HUD UNLOCKED!
                        boolean allowDrag = (!locked) || ("btn_gx_main".equals(key)
                                && Math.hypot(event.getRawX() - startRawX, event.getRawY() - startRawY) > dp(24));
                        if (allowDrag) {
                            float dx = event.getRawX() - startRawX;
                            float dy = event.getRawY() - startRawY;
                            if (Math.hypot(dx, dy) > touchSlop || isDragging) {
                                isDragging = true;
                                float nx = Math.max(0f, initialX + dx);
                                float ny = Math.max(0f, initialY + dy);
                                if (isSystemOverlay && item != null && item.wmParams != null) {
                                    item.wmParams.x = Math.round(nx);
                                    item.wmParams.y = Math.round(ny);
                                    try {
                                        windowManager.updateViewLayout(v, item.wmParams);
                                    } catch (Throwable ignored) {
                                    }
                                } else {
                                    v.setX(nx);
                                    v.setY(ny);
                                }
                                ClientSettingsStore.saveWidgetPosition(context, key, nx, ny);
                            }
                        }
                        return true;

                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        if (locked && onHoldAction != null) {
                            onHoldAction.onHoldChanged(false);
                        }
                        if (!isDragging && onTapAction != null) {
                            onTapAction.run();
                        }
                        isDragging = false;
                        return true;
                }
                return false;
            }
        });
    }

    private FloatingItem findItem(View v) {
        for (FloatingItem item : floatingItems) {
            if (item.view == v) return item;
        }
        return null;
    }

    private void buildClickGuiModal() {
        clickGuiModal = new FrameLayout(context);
        clickGuiModal.setBackgroundColor(Color.parseColor("#CC05070A"));
        clickGuiModal.setVisibility(View.GONE);

        LinearLayout card = new LinearLayout(context);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(12), dp(16), dp(12));
        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(Color.parseColor("#F50F131A"));
        cardBg.setCornerRadius(dp(14));
        cardBg.setStroke(dp(1), Color.parseColor("#00E5FF"));
        card.setBackground(cardBg);

        FrameLayout.LayoutParams cardLp = new FrameLayout.LayoutParams(dp(530), dp(310));
        cardLp.gravity = Gravity.CENTER;

        LinearLayout header = new LinearLayout(context);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(context);
        title.setText("GAMEXCLIENT // IN-GAME MOD MENU");
        title.setTextColor(Color.parseColor("#00E5FF"));
        title.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        header.addView(title, titleLp);

        btnLockToggleHeader = new Button(context);
        btnLockToggleHeader.setAllCaps(false);
        btnLockToggleHeader.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        btnLockToggleHeader.setOnClickListener(v -> {
            boolean nextLocked = !ClientSettingsStore.isHudLocked(context);
            ClientSettingsStore.setHudLocked(context, nextLocked);
            refreshAllStates();
            Toast.makeText(context, nextLocked
                    ? "HUD DIKUNCI (Sentuhan tembus ke game)"
                    : "MODE GESER HUD AKTIF (Tarik widget di layar)", Toast.LENGTH_SHORT).show();
        });
        header.addView(btnLockToggleHeader);

        Button btnAllOff = new Button(context);
        btnAllOff.setText("MATIKAN SEMUA");
        btnAllOff.setAllCaps(false);
        btnAllOff.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        btnAllOff.setTextColor(Color.parseColor("#FDE047"));
        btnAllOff.setBackgroundColor(Color.parseColor("#1E293B"));
        LinearLayout.LayoutParams offLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        offLp.leftMargin = dp(6);
        btnAllOff.setLayoutParams(offLp);
        btnAllOff.setOnClickListener(v -> {
            ClientSettingsStore.setAllHudFeatures(context, false);
            refreshAllStates();
        });
        header.addView(btnAllOff);

        Button btnClose = new Button(context);
        btnClose.setText("TUTUP [X]");
        btnClose.setAllCaps(false);
        btnClose.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        btnClose.setTextColor(Color.parseColor("#F87171"));
        btnClose.setBackgroundColor(Color.TRANSPARENT);
        btnClose.setOnClickListener(v -> clickGuiModal.setVisibility(View.GONE));
        header.addView(btnClose);

        card.addView(header);

        TextView hintLine = new TextView(context);
        hintLine.setText("Ketuk modul untuk ON / OFF secara real-time di atas Minecraft. Geser HUD saat tombol kuning [BISA DIGESER] aktif.");
        hintLine.setTextColor(Color.parseColor("#94A3B8"));
        hintLine.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        hintLine.setPadding(0, dp(4), 0, dp(8));
        card.addView(hintLine);

        ScrollView scroll = new ScrollView(context);
        LinearLayout columns = new LinearLayout(context);
        columns.setOrientation(LinearLayout.HORIZONTAL);

        LinearLayout colLeft = new LinearLayout(context);
        colLeft.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams colLp1 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        colLp1.rightMargin = dp(6);

        LinearLayout colRight = new LinearLayout(context);
        colRight.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams colLp2 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        colLp2.leftMargin = dp(6);

        colLeft.addView(createCategoryHeader("3A // PERFORMA & VISUAL"));
        for (int i = 0; i <= 5; i++) {
            colLeft.addView(createModuleToggleRow(NativeBridge.FEATURE_NAMES[i], i));
        }

        colRight.addView(createCategoryHeader("3B // HUD & PVP MOBILE"));
        for (int i = 6; i <= 11; i++) {
            colRight.addView(createModuleToggleRow(NativeBridge.FEATURE_NAMES[i], i));
        }

        columns.addView(colLeft, colLp1);
        columns.addView(colRight, colLp2);
        scroll.addView(columns);
        card.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        clickGuiModal.addView(card, cardLp);

        if (isSystemOverlay) {
            WindowManager.LayoutParams modalLp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    getOverlayWindowType(),
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT
            );
            modalLp.gravity = Gravity.CENTER;
            try {
                windowManager.addView(clickGuiModal, modalLp);
            } catch (Throwable ignored) {
            }
        } else {
            inAppContainer.addView(clickGuiModal, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
            ));
        }
    }

    private TextView createCategoryHeader(String text) {
        TextView tv = new TextView(context);
        tv.setText(text);
        tv.setTextColor(Color.parseColor("#38BDF8"));
        tv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        tv.setPadding(0, dp(2), 0, dp(6));
        return tv;
    }

    private View createModuleToggleRow(String title, int featId) {
        TextView row = new TextView(context);
        row.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        row.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        row.setPadding(dp(10), dp(8), dp(10), dp(8));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.bottomMargin = dp(6);
        row.setLayoutParams(lp);

        Runnable updateStyle = () -> {
            boolean on = ClientSettingsStore.isFeatureEnabled(context, featId);
            row.setText((on ? "[ON]  " : "[OFF] ") + title);
            row.setTextColor(on ? Color.parseColor("#10B981") : Color.parseColor("#94A3B8"));
            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(dp(8));
            bg.setColor(on ? Color.parseColor("#0D2821") : Color.parseColor("#131822"));
            bg.setStroke(dp(1), on ? Color.parseColor("#10B981") : Color.parseColor("#1E293B"));
            row.setBackground(bg);
        };
        clickGuiRowUpdaters.add(updateStyle);
        updateStyle.run();

        row.setOnClickListener(v -> {
            boolean next = !ClientSettingsStore.isFeatureEnabled(context, featId);
            ClientSettingsStore.setFeatureEnabled(context, featId, next);
            refreshAllStates();
            if (hostActivity != null) {
                applyHighRefreshRate(hostActivity.getWindow());
            }
        });
        return row;
    }

    public void refreshAllStates() {
        boolean locked = ClientSettingsStore.isHudLocked(context);
        if (btnLockToggleHeader != null) {
            btnLockToggleHeader.setText(locked ? "HUD: TERKUNCI [LOCK]" : "HUD: BISA DIGESER [EDIT]");
            btnLockToggleHeader.setTextColor(Color.parseColor("#0B0D11"));
            btnLockToggleHeader.setBackgroundColor(locked
                    ? Color.parseColor("#10B981")
                    : Color.parseColor("#F59E0B"));
        }

        for (Runnable r : clickGuiRowUpdaters) {
            r.run();
        }

        // 1. Update Fullbright Overlay + Hardware Screen Brightness Override (100% nyata!)
        boolean fbEnabled = ClientSettingsStore.isFeatureEnabled(context, NativeBridge.FEAT_FULLBRIGHT);
        if (fullbrightOverlayView != null) {
            fullbrightOverlayView.setVisibility(fbEnabled ? View.VISIBLE : View.GONE);
        }
        if (isSystemOverlay && watcherParams != null) {
            watcherParams.screenBrightness = fbEnabled
                    ? 1.0f
                    : WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE;
            if (ClientSettingsStore.isFeatureEnabled(context, NativeBridge.FEAT_FPS_UNLOCKER)
                    && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                watcherParams.preferredDisplayModeId = findBestDisplayModeId();
            }
            try {
                windowManager.updateViewLayout(outsideTouchWatcher, watcherParams);
            } catch (Throwable ignored) {
            }
        }

        // 2. Update Custom PvP Crosshair & Zoom Scope
        if (centerScopeView != null) {
            boolean chEnabled = ClientSettingsStore.isFeatureEnabled(context, NativeBridge.FEAT_CUSTOM_CROSSHAIR);
            centerScopeView.setCrosshairEnabled(chEnabled);
        }

        // 3. Update semua Floating HUD Widgets
        for (FloatingItem item : floatingItems) {
            boolean visible = (item.featId == -1) || ClientSettingsStore.isFeatureEnabled(context, item.featId);
            item.view.setVisibility(visible ? View.VISIBLE : View.GONE);

            if (item.view instanceof TextView && item.featId != -1) {
                GradientDrawable bg = new GradientDrawable();
                bg.setColor(Color.parseColor("#D90B0D11"));
                bg.setCornerRadius(dp(7));
                bg.setStroke(dp(locked ? 1 : 2), Color.parseColor(locked ? "#4D00E5FF" : "#F59E0B"));
                item.view.setBackground(bg);
            }

            if (isSystemOverlay && item.wmParams != null && item.passiveInfoWidget) {
                int baseFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
                if (locked) {
                    baseFlags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
                }
                if (item.wmParams.flags != baseFlags) {
                    item.wmParams.flags = baseFlags;
                    try {
                        windowManager.updateViewLayout(item.view, item.wmParams);
                    } catch (Throwable ignored) {
                    }
                }
            }
        }
    }

    public void toggleClickGui() {
        if (clickGuiModal.getVisibility() == View.VISIBLE) {
            clickGuiModal.setVisibility(View.GONE);
        } else {
            refreshAllStates();
            clickGuiModal.setVisibility(View.VISIBLE);
        }
    }

    private TextView createHudBadge(String initialText) {
        TextView tv = new TextView(context);
        tv.setText(initialText);
        tv.setTextColor(Color.parseColor("#F1F5F9"));
        tv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        tv.setPadding(dp(10), dp(5), dp(10), dp(5));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#D90B0D11"));
        bg.setCornerRadius(dp(7));
        bg.setStroke(dp(1), Color.parseColor("#4D00E5FF"));
        tv.setBackground(bg);
        return tv;
    }

    private TextView createActionChip(String label, String hexAccent) {
        TextView tv = new TextView(context);
        tv.setText(label);
        tv.setTextColor(Color.parseColor(hexAccent));
        tv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        tv.setPadding(dp(10), dp(6), dp(10), dp(6));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#E60B0D11"));
        bg.setCornerRadius(dp(8));
        bg.setStroke(dp(1), Color.parseColor(hexAccent));
        tv.setBackground(bg);
        return tv;
    }

    private interface HoldCallback {
        void onHoldChanged(boolean active);
    }

    private void startChoreographerLoop() {
        running = true;
        fpsWindowStartMs = SystemClock.uptimeMillis();
        Choreographer.getInstance().postFrameCallback(new Choreographer.FrameCallback() {
            @Override
            public void doFrame(long frameTimeNanos) {
                if (!running) return;
                if (lastFrameNanos != 0) {
                    currentFrameMs = (frameTimeNanos - lastFrameNanos) / 1_000_000.0f;
                    if (NativeBridge.isNativeLoaded()) {
                        NativeBridge.nativeTickEffectiveFov(70.0f, currentFrameMs / 1000.0f);
                    }
                }
                lastFrameNanos = frameTimeNanos;
                frameCounter++;

                long nowMs = SystemClock.uptimeMillis();
                while (!lmbClicks.isEmpty() && nowMs - lmbClicks.peekFirst() > 1000) {
                    lmbClicks.removeFirst();
                }

                if (touchstrokesView != null) {
                    touchstrokesView.checkDecay(nowMs);
                }

                if (nowMs - fpsWindowStartMs >= 250) {
                    currentFps = Math.round((frameCounter * 1000.0f) / (nowMs - fpsWindowStartMs));
                    frameCounter = 0;
                    fpsWindowStartMs = nowMs;

                    int cps = lmbClicks.size();
                    tvFpsCps.setText(String.format(Locale.US, "%d FPS | %.1f ms | %d CPS",
                            currentFps, currentFrameMs, cps));

                    if (nowMs - lastAttackMs > 2800 && comboCount > 0) {
                        comboCount = 0;
                        lastReachBlocks = 0.0f;
                        updateCombatHudText();
                    }
                }
                Choreographer.getInstance().postFrameCallback(this);
            }
        });
    }

    private void updateCombatHudText() {
        tvComboReach.setText(String.format(Locale.US, "COMBO: %dx | REACH: %.2fm",
                comboCount, lastReachBlocks));
    }

    public void destroy() {
        running = false;
        if (isSystemOverlay && windowManager != null) {
            for (FloatingItem item : floatingItems) {
                try {
                    windowManager.removeView(item.view);
                } catch (Throwable ignored) {
                }
            }
            if (outsideTouchWatcher != null) {
                try {
                    windowManager.removeView(outsideTouchWatcher);
                } catch (Throwable ignored) {
                }
            }
            if (fullbrightOverlayView != null) {
                try {
                    windowManager.removeView(fullbrightOverlayView);
                } catch (Throwable ignored) {
                }
            }
            if (centerScopeView != null) {
                try {
                    windowManager.removeView(centerScopeView);
                } catch (Throwable ignored) {
                }
            }
            if (clickGuiModal != null) {
                try {
                    windowManager.removeView(clickGuiModal);
                } catch (Throwable ignored) {
                }
            }
        }
    }

    private int dp(int val) {
        return Math.round(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, val, context.getResources().getDisplayMetrics()));
    }

    /**
     * Custom Center PvP Crosshair + Tactical Zoom Scope + Hit Marker
     */
    private static class CenterCrosshairScopeView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private boolean crosshairEnabled = true;
        private boolean zoomScopeActive = false;
        private boolean showCompassRing = false;
        private long lastHitPulseMs = 0;

        public CenterCrosshairScopeView(Context context) {
            super(context);
        }

        public void setCrosshairEnabled(boolean enabled) {
            this.crosshairEnabled = enabled;
            invalidate();
        }

        public void setZoomScopeActive(boolean active) {
            this.zoomScopeActive = active;
            invalidate();
        }

        public void setShowCompassRing(boolean show) {
            this.showCompassRing = show;
            invalidate();
        }

        public void pulseHitMarker() {
            this.lastHitPulseMs = SystemClock.uptimeMillis();
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float cx = getWidth() * 0.5f;
            float cy = getHeight() * 0.5f;
            long now = SystemClock.uptimeMillis();
            boolean hitActive = (now - lastHitPulseMs) < 180;

            if (zoomScopeActive) {
                // Gambar Reticle Scope Zoom 4x
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(2.5f);
                paint.setColor(Color.parseColor("#CC10B981"));
                canvas.drawCircle(cx, cy, cx * 0.72f, paint);
                paint.setStrokeWidth(1.5f);
                canvas.drawCircle(cx, cy, cx * 0.36f, paint);
                canvas.drawLine(cx - cx * 0.85f, cy, cx + cx * 0.85f, cy, paint);
                canvas.drawLine(cx, cy - cy * 0.85f, cx, cy + cy * 0.85f, paint);
            }

            if (showCompassRing) {
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(2f);
                paint.setColor(Color.parseColor("#99A855F7"));
                canvas.drawCircle(cx, cy, cx * 0.55f, paint);
            }

            if (crosshairEnabled) {
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(3.0f);
                paint.setColor(hitActive ? Color.parseColor("#F43F5E") : Color.parseColor("#00E5FF"));

                float gap = 8f;
                float len = 18f;
                canvas.drawLine(cx - gap - len, cy, cx - gap, cy, paint);
                canvas.drawLine(cx + gap, cy, cx + gap + len, cy, paint);
                canvas.drawLine(cx, cy - gap - len, cx, cy - gap, paint);
                canvas.drawLine(cx, cy + gap, cx, cy + gap + len, paint);

                // Hitmarker diagonal X saat menyerang
                if (hitActive) {
                    float d = 12f;
                    canvas.drawLine(cx - d, cy - d, cx - 4f, cy - 4f, paint);
                    canvas.drawLine(cx + 4f, cy + 4f, cx + d, cy + d, paint);
                    canvas.drawLine(cx + d, cy - d, cx + 4f, cy - 4f, paint);
                    canvas.drawLine(cx - 4f, cy + 4f, cx - d, cy + d, paint);
                }

                paint.setStyle(Paint.Style.FILL);
                canvas.drawCircle(cx, cy, 2.5f, paint);
            }
        }
    }

    private static class TouchstrokesView extends View {
        private final Paint boxPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();
        private boolean wDown, aDown, sDown, dDown, atkDown;
        private long lastPulseMs = 0;

        public TouchstrokesView(Context context, Runnable onTap) {
            super(context);
            strokePaint.setStyle(Paint.Style.STROKE);
            strokePaint.setStrokeWidth(2.5f);
            strokePaint.setColor(Color.parseColor("#4D00E5FF"));

            textPaint.setColor(Color.parseColor("#F8FAFC"));
            textPaint.setTextSize(22f);
            textPaint.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
            textPaint.setTextAlign(Paint.Align.CENTER);
        }

        public void pulseTouchKey(int idx, long nowMs) {
            this.lastPulseMs = nowMs;
            this.atkDown = true;
            this.wDown = true;
            this.aDown = (idx == 1);
            this.dDown = (idx == 2);
            this.sDown = (idx == 3);
            invalidate();
        }

        public void checkDecay(long nowMs) {
            if (lastPulseMs != 0 && nowMs - lastPulseMs > 180) {
                clearKeys();
            }
        }

        public void clearKeys() {
            lastPulseMs = 0;
            wDown = aDown = sDown = dDown = atkDown = false;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float cellW = (w - 16f) / 3f;
            float cellH = (h - 16f) / 3f;

            drawKey(canvas, cellW + 4f, 2f, cellW, cellH, "W", wDown);
            drawKey(canvas, 2f, cellH + 6f, cellW, cellH, "A", aDown);
            drawKey(canvas, cellW + 4f, cellH + 6f, cellW, cellH, "S", sDown);
            drawKey(canvas, (cellW * 2f) + 6f, cellH + 6f, cellW, cellH, "D", dDown);
            drawKey(canvas, 2f, (cellH * 2f) + 10f, (cellW * 1.5f) - 2f, cellH, "ATK", atkDown);
            drawKey(canvas, (cellW * 1.5f) + 6f, (cellH * 2f) + 10f, (cellW * 1.5f), cellH, "JUMP", wDown);
        }

        private void drawKey(Canvas c, float x, float y, float kw, float kh, String label, boolean active) {
            rect.set(x, y, x + kw, y + kh);
            boxPaint.setColor(active ? Color.parseColor("#B300E5FF") : Color.parseColor("#BF0B0D11"));
            c.drawRoundRect(rect, 10f, 10f, boxPaint);
            c.drawRoundRect(rect, 10f, 10f, strokePaint);
            Paint.FontMetrics fm = textPaint.getFontMetrics();
            float ty = rect.centerY() - (fm.ascent + fm.descent) / 2f;
            c.drawText(label, rect.centerX(), ty, textPaint);
        }
    }
}
