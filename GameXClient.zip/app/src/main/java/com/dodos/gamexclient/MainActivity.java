package com.dodos.gamexclient;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

public class MainActivity extends Activity {
    private TextView tvStatus;
    private TextView tvNativeDiag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        ClientSettingsStore.syncAllToNative(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.HORIZONTAL);
        root.setBackgroundColor(Color.parseColor("#0B0D11"));
        root.setPadding(dp(20), dp(16), dp(20), dp(16));

        LinearLayout leftPanel = new LinearLayout(this);
        leftPanel.setOrientation(LinearLayout.VERTICAL);
        leftPanel.setPadding(dp(18), dp(18), dp(18), dp(18));
        GradientDrawable leftBg = new GradientDrawable();
        leftBg.setColor(Color.parseColor("#12161F"));
        leftBg.setCornerRadius(dp(14));
        leftBg.setStroke(dp(1), Color.parseColor("#1E293B"));
        leftPanel.setBackground(leftBg);

        LinearLayout.LayoutParams leftLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.15f);
        leftLp.rightMargin = dp(16);

        TextView badge = new TextView(this);
        badge.setText("MINECRAFT BEDROCK // NATIVE CLIENT");
        badge.setTextColor(Color.parseColor("#00E5FF"));
        badge.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        badge.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        leftPanel.addView(badge);

        TextView title = new TextView(this);
        title.setText("GameXClient");
        title.setTextColor(Color.parseColor("#F8FAFC"));
        title.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26);
        title.setPadding(0, dp(4), 0, dp(4));
        leftPanel.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Arsitektur ARM64 C++ (.so) + Matte-Dark ClickGUI (3A Performa & Kamera + 3B PvP HUD)");
        subtitle.setTextColor(Color.parseColor("#94A3B8"));
        subtitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        leftPanel.addView(subtitle);

        tvStatus = new TextView(this);
        tvStatus.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
        tvStatus.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        tvStatus.setTextColor(Color.parseColor("#10B981"));
        tvStatus.setPadding(dp(12), dp(10), dp(12), dp(10));
        GradientDrawable diagBg = new GradientDrawable();
        diagBg.setColor(Color.parseColor("#090C10"));
        diagBg.setCornerRadius(dp(8));
        diagBg.setStroke(dp(1), Color.parseColor("#1E293B"));
        tvStatus.setBackground(diagBg);
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        statusLp.topMargin = dp(12);
        leftPanel.addView(tvStatus, statusLp);

        tvNativeDiag = new TextView(this);
        tvNativeDiag.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
        tvNativeDiag.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        tvNativeDiag.setTextColor(Color.parseColor("#38BDF8"));
        tvNativeDiag.setPadding(0, dp(8), 0, dp(8));
        leftPanel.addView(tvNativeDiag);

        LinearLayout fpsRow = new LinearLayout(this);
        fpsRow.setOrientation(LinearLayout.HORIZONTAL);
        fpsRow.setGravity(Gravity.CENTER_VERTICAL);
        for (int fpsVal : new int[]{60, 90, 120, 144}) {
            Button b = new Button(this);
            b.setText(fpsVal + " FPS");
            b.setAllCaps(false);
            b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            b.setTextColor(Color.parseColor("#F8FAFC"));
            b.setBackgroundColor(Color.parseColor("#1E293B"));
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(0, dp(36), 1f);
            blp.rightMargin = dp(4);
            b.setOnClickListener(v -> {
                ClientSettingsStore.setTargetFps(this, fpsVal);
                refreshDiagnostics();
                Toast.makeText(this, "Target FPS disetel ke " + fpsVal + " Hz", Toast.LENGTH_SHORT).show();
            });
            fpsRow.addView(b, blp);
        }
        leftPanel.addView(fpsRow);

        ScrollView rightScroll = new ScrollView(this);
        LinearLayout rightPanel = new LinearLayout(this);
        rightPanel.setOrientation(LinearLayout.VERTICAL);

        rightPanel.addView(createPrimaryButton(
                "LAUNCH GAMEX IN-PROCESS ENGINE",
                "Muat libminecraftpe.so + libgamexclient.so & buka ClickGUI langsung",
                "#00E5FF", "#082F49",
                v -> {
                    Intent i = new Intent(this, GameHostActivity.class);
                    i.putExtra("bridge_launch", false);
                    startActivity(i);
                }
        ));

        rightPanel.addView(createPrimaryButton(
                "LAUNCH MINECRAFT + OVERLAY HUD",
                "Aktifkan Floating ClickGUI di atas Minecraft Google Play resmi",
                "#10B981", "#064E3B",
                v -> launchWithSystemOverlay()
        ));

        rightPanel.addView(createPrimaryButton(
                "EXPORT MOD (.LEVIPACK / .SO)",
                "Ekspor libgamexclient.so untuk diimpor ke LeviLauncher",
                "#A855F7", "#3B0764",
                v -> {
                    File pack = McpePackageExtractor.exportStandaloneLevipack(this);
                    if (pack != null) {
                        Toast.makeText(this, "Berhasil diekspor ke: " + pack.getAbsolutePath(), Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(this, "Gagal mengekspor .levipack", Toast.LENGTH_SHORT).show();
                    }
                }
        ));

        rightScroll.addView(rightPanel);
        root.addView(leftPanel, leftLp);
        root.addView(rightScroll, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

        setContentView(root);
        refreshDiagnostics();
    }

    private void launchWithSystemOverlay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izinkan 'Tampilkan di atas aplikasi lain' untuk menampilkan ClickGUI di atas Minecraft", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
            return;
        }
        Intent i = new Intent(this, GameHostActivity.class);
        i.putExtra("bridge_launch", true);
        startActivity(i);
    }

    private View createPrimaryButton(String headline, String sub, String borderHex, String bgHex, View.OnClickListener listener) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(14), dp(16), dp(14));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(bgHex));
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), Color.parseColor(borderHex));
        box.setBackground(bg);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(12);
        box.setLayoutParams(lp);

        TextView h = new TextView(this);
        h.setText(headline);
        h.setTextColor(Color.parseColor(borderHex));
        h.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        h.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        box.addView(h);

        TextView s = new TextView(this);
        s.setText(sub);
        s.setTextColor(Color.parseColor("#E2E8F0"));
        s.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        s.setPadding(0, dp(4), 0, 0);
        box.addView(s);

        box.setOnClickListener(listener);
        return box;
    }

    private void refreshDiagnostics() {
        McpePackageExtractor.McpeEnvironment env = McpePackageExtractor.inspectAndPrepare(this, false);
        String mcStatus = env.installed
                ? "MCPE Terdeteksi: v" + env.versionName + " (" + (env.splitApkPaths.size() + 1) + " APK Splits)"
                : "MCPE Google Play belum terdeteksi (Mode Sandbox ClickGUI siap)";
        String fpsInfo = "Target Frame Rate: " + ClientSettingsStore.getTargetFps(this) + " Hz | Keystore: Deterministic JKS";
        tvStatus.setText(mcStatus + "\n" + fpsInfo);
        tvNativeDiag.setText(NativeBridge.isNativeLoaded()
                ? NativeBridge.nativeGetEngineDiagnostic()
                : "Native Engine: menunggu inisialisasi NDK");
    }

    private int dp(int val) {
        return Math.round(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, val, getResources().getDisplayMetrics()));
    }
}
