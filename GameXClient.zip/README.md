# GameXClient v1.1 — Minecraft Bedrock Android Native Client (ARM64 C++20)

Pembaruan v1.1 memperbaiki:
1. **Bebas Layar Hitam (Direct Launch):** Tombol `MAIN MINECRAFT + GAMEX HUD` langsung mengaktifkan *Floating Window Service* per-widget dan membuka aplikasi Minecraft resmi tanpa terjebak di layar hitam.
2. **Sistem Kunci HUD (`HUD: TERKUNCI` vs `BISA DIGESER`):** Saat HUD dikunci (default), widget menggunakan `FLAG_NOT_TOUCHABLE` sehingga sentuhan jari tembus 100% ke dalam Minecraft dan widget tidak bisa bergeser.
3. **Pilihan ON/OFF per Fitur & Nonaktifkan Semua:** Tersedia langsung di halaman utama Launcher maupun lewat tombol melayang `[GX]` di dalam game. Default awal bersih (hanya FPS/CPS Counter yang aktif).
